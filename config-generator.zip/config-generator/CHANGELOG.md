# 更新日志

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2026-02-06

### Added
- Initial release of Node.js Config Generator
- Support for multiple project types (api, cli, fullstack)
- Framework support for Express, Koa, and NestJS
- TypeScript configuration generation
- ESLint and Prettier integration
- Jest and Vitest test framework support
- Interactive configuration prompts
- Command-line argument support
- Project configuration checking
- Git repository initialization
- GitHub Actions workflow generation
- Multiple package manager support (npm, yarn, pnpm)

### Features
- 🚀 Quick project initialization with interactive prompts
- 🎨 Beautiful CLI output with colors and loading animations
- 📦 Smart dependency management
- 🔧 Comprehensive configuration templates
- 📝 Detailed README generation
- 🧪 Test setup configuration

### Project Structure
```
config-generator/
├── bin/                    # CLI entry point
├── src/                   # Source code
│   ├── commands/         # Command modules
│   ├── prompts/          # Interactive prompts
│   ├── generators/       # File generators
│   └── utils/            # Utility functions
├── test/                  # Test files
├── templates/            # Template files
└── docs/                 # Documentation
```

### Commands
- `config-gen init` - Initialize a new project
- `config-gen check` - Check project configuration

## [0.1.0] - 2026-02-01

### Added
- Initial project setup
- Basic CLI structure
- Proof of concept implementation

[1.0.0]: https://github.com/dramvfia/config-generator/releases/tag/v1.0.0
[0.1.0]: https://github.com/dramvfia/config-generator/releases/tag/v0.1.0
