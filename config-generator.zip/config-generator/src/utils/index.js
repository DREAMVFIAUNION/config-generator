/**
 * 工具模块索引
 * 
 * 导出所有工具模块
 * 
 * @author DRAMVFIA UNION
 */

'use strict';

const fileSystem = require('./fileSystem');
const logger = require('./logger');

module.exports = {
  fileSystem,
  logger,
  default: {
    fileSystem,
    logger
  }
};
