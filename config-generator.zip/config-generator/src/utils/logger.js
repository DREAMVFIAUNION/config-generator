/**
 * 日志工具模块
 * 
 * 提供美化日志输出功能
 * 
 * @author DRAMVFIA UNION
 */

'use strict';

const chalk = require('chalk');
const ora = require('ora');

/**
 * 日志级别
 */
const LOG_LEVELS = {
  error: 0,
  warn: 1,
  info: 2,
  success: 3,
  debug: 4
};

/**
 * 默认配置
 */
const defaultConfig = {
  level: 'info',
  showTimestamp: true,
  showLevel: true,
  prefix: ''
};

/**
 * 日志类
 */
class Logger {
  constructor(config = {}) {
    this.config = { ...defaultConfig, ...config };
    this.spinner = null;
  }

  /**
   * 获取当前日志级别
   */
  get level() {
    return this.config.level;
  }

  /**
   * 设置日志级别
   */
  set level(value) {
    this.config.level = value;
  }

  /**
   * 检查是否可以输出
   * @param {string} level - 日志级别
   */
  canLog(level) {
    return LOG_LEVELS[level] <= LOG_LEVELS[this.config.level];
  }

  /**
   * 格式化消息
   * @param {string} message - 消息内容
   * @param {string} level - 日志级别
   */
  formatMessage(message, level) {
    const parts = [];

    if (this.config.showTimestamp) {
      const now = new Date();
      const timestamp = now.toLocaleTimeString('zh-CN', {
        hour12: false,
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
      });
      parts.push(chalk.gray(`[${timestamp}]`));
    }

    if (this.config.showLevel) {
      const levelLabels = {
        error: 'ERROR',
        warn: 'WARN',
        info: 'INFO',
        success: 'OK',
        debug: 'DEBUG'
      };
      const levelColors = {
        error: chalk.red,
        warn: chalk.yellow,
        info: chalk.cyan,
        success: chalk.green,
        debug: chalk.gray
      };
      parts.push(levelColors[level](levelLabels[level].padEnd(7)));
    }

    if (this.config.prefix) {
      parts.push(chalk.magenta(this.config.prefix));
    }

    parts.push(message);

    return parts.join(' ');
  }

  /**
   * 错误日志
   * @param {string} message - 消息内容
   * @param {Object} options - 选项
   */
  error(message, options = {}) {
    if (!this.canLog('error')) return;

    const formattedMessage = this.formatMessage(chalk.red(message), 'error');
    console.error(formattedMessage);

    if (options.error && options.error.stack) {
      console.error(chalk.gray(options.error.stack));
    }
  }

  /**
   * 警告日志
   * @param {string} message - 消息内容
   */
  warn(message) {
    if (!this.canLog('warn')) return;

    const formattedMessage = this.formatMessage(chalk.yellow(message), 'warn');
    console.warn(formattedMessage);
  }

  /**
   * 信息日志
   * @param {string} message - 消息内容
   */
  info(message) {
    if (!this.canLog('info')) return;

    const formattedMessage = this.formatMessage(chalk.cyan(message), 'info');
    console.log(formattedMessage);
  }

  /**
   * 成功日志
   * @param {string} message - 消息内容
   */
  success(message) {
    if (!this.canLog('success')) return;

    const formattedMessage = this.formatMessage(chalk.green(message), 'success');
    console.log(formattedMessage);
  }

  /**
   * 调试日志
   * @param {string} message - 消息内容
   */
  debug(message) {
    if (!this.canLog('debug')) return;

    const formattedMessage = this.formatMessage(chalk.gray(message), 'debug');
    console.log(formattedMessage);
  }

  /**
   * 创建加载动画
   * @param {string} text - 初始文本
   */
  createSpinner(text) {
    this.spinner = ora({
      text: text,
      spinner: 'dots',
      color: 'cyan'
    });
    return this.spinner;
  }

  /**
   * 启动加载动画
   * @param {string} text - 初始文本
   */
  start(text) {
    if (!this.spinner) {
      this.spinner = ora({
        text: text,
        spinner: 'dots',
        color: 'cyan'
      });
    }
    this.spinner.start(text);
  }

  /**
   * 更新加载动画文本
   * @param {string} text - 新文本
   */
  setSpinnerText(text) {
    if (this.spinner) {
      this.spinner.text = text;
    }
  }

  /**
   * 成功状态
   * @param {string} text - 完成文本
   */
  succeed(text) {
    if (this.spinner) {
      this.spinner.succeed(text);
      this.spinner = null;
    }
  }

  /**
   * 失败状态
   * @param {string} text - 失败文本
   */
  fail(text) {
    if (this.spinner) {
      this.spinner.fail(text);
      this.spinner = null;
    }
  }

  /**
   * 警告状态
   * @param {string} text - 警告文本
   */
  warn(text) {
    if (this.spinner) {
      this.spinner.warn(text);
      this.spinner = null;
    }
  }

  /**
   * 信息状态
   * @param {string} text - 信息文本
   */
  info(text) {
    if (this.spinner) {
      this.spinner.info(text);
      this.spinner = null;
    }
  }

  /**
   * 停止加载动画
   */
  stop() {
    if (this.spinner) {
      this.spinner.stop();
      this.spinner = null;
    }
  }

  /**
   * 打印分隔线
   * @param {string} char - 分隔符
   * @param {number} length - 长度
   */
  divider(char = '─', length = 50) {
    console.log(chalk.gray(char.repeat(length)));
  }

  /**
   * 打印标题
   * @param {string} title - 标题文本
   * @param {string} style - 样式风格
   */
  title(title, style = 'cyan') {
    const styles = {
      cyan: chalk.cyan,
      green: chalk.green,
      yellow: chalk.yellow,
      red: chalk.red,
      magenta: chalk.magenta
    };
    
    const padding = ' '.repeat(2);
    const line = '═'.repeat(title.length + 4);
    
    console.log();
    console.log(styles[style](line));
    console.log(styles[style](`${padding}${title}`));
    console.log(styles[style](line));
    console.log();
  }

  /**
   * 打印列表
   * @param {string[]} items - 列表项
   * @param {string} style - 样式风格
   */
  list(items, style = 'white') {
    const styles = {
      white: chalk.white,
      cyan: chalk.cyan,
      green: chalk.green,
      yellow: chalk.yellow
    };

    for (const item of items) {
      console.log(`  ${styles[style]('•')} ${item}`);
    }
  }

  /**
   * 打印表格
   * @param {Array} rows - 表格数据
   * @param {string[]} headers - 表头
   */
  table(rows, headers) {
    const allRows = [headers, ...rows];
    const colWidths = headers.map((_, colIndex) => {
      return Math.max(
        ...allRows.map(row => (row[colIndex] || '').toString().length)
      );
    });

    const border = '│';
    const separator = '─'.repeat(colWidths.reduce((a, b) => a + b + 3, 0) + 1);

    // 打印表头
    console.log(`┌${separator}┐`);
    console.log(`${border} ${headers.map((h, i) => h.padEnd(colWidths[i])).join(' │ ')} ${border}`);
    console.log(`├${separator}┤`);

    // 打印数据行
    for (const row of rows) {
      console.log(`${border} ${row.map((c, i) => (c || '').toString().padEnd(colWidths[i])).join(' │ ')} ${border}`);
    }

    console.log(`└${separator}┘`);
  }
}

/**
 * 创建logger实例
 * @param {Object} config - 配置
 * @returns {Logger} logger实例
 */
function createLogger(config = {}) {
  return new Logger(config);
}

// 默认logger实例
const logger = createLogger();

module.exports = {
  Logger,
  createLogger,
  default: logger
};
