/**
 * 文件系统工具模块
 * 
 * 提供文件操作相关的工具函数
 * 
 * @author DRAMVFIA UNION
 */

'use strict';

const fs = require('fs-extra');
const path = require('path');
const crypto = require('crypto');

/**
 * 递归创建目录
 * @param {string} dirPath - 目录路径
 * @returns {Promise<void>}
 */
async function ensureDir(dirPath) {
  await fs.ensureDir(dirPath);
}

/**
 * 递归删除目录
 * @param {string} dirPath - 目录路径
 * @returns {Promise<void>}
 */
async function removeDir(dirPath) {
  await fs.remove(dirPath);
}

/**
 * 复制目录
 * @param {string} source - 源目录
 * @param {string} destination - 目标目录
 * @returns {Promise<void>}
 */
async function copyDir(source, destination) {
  await fs.copy(source, destination);
}

/**
 * 读取文件内容
 * @param {string} filePath - 文件路径
 * @returns {Promise<string>} 文件内容
 */
async function readFile(filePath) {
  return await fs.readFile(filePath, 'utf8');
}

/**
 * 写入文件
 * @param {string} filePath - 文件路径
 * @param {string} content - 文件内容
 * @returns {Promise<void>}
 */
async function writeFile(filePath, content) {
  await fs.writeFile(filePath, content, 'utf8');
}

/**
 * 追加写入文件
 * @param {string} filePath - 文件路径
 * @param {string} content - 要追加的内容
 * @returns {Promise<void>}
 */
async function appendFile(filePath, content) {
  await fs.appendFile(filePath, content, 'utf8');
}

/**
 * 检查文件是否存在
 * @param {string} filePath - 文件路径
 * @returns {Promise<boolean>} 是否存在
 */
async function exists(filePath) {
  return await fs.pathExists(filePath);
}

/**
 * 获取目录下的所有文件
 * @param {string} dirPath - 目录路径
 * @param {Object} options - 选项
 * @returns {Promise<string[]>} 文件路径列表
 */
async function readDir(dirPath, options = {}) {
  const result = await fs.readdir(dirPath, options);
  return result;
}

/**
 * 获取目录下的所有文件（递归）
 * @param {string} dirPath - 目录路径
 * @param {string} baseDir - 基础目录
 * @returns {Promise<string[]>} 文件路径列表
 */
async function readDirRecursive(dirPath, baseDir = '') {
  const files = [];
  const entries = await fs.readdir(dirPath, { withFileTypes: true });

  for (const entry of entries) {
    const fullPath = path.join(dirPath, entry.name);
    const relativePath = path.join(baseDir, entry.name);

    if (entry.isDirectory()) {
      const subFiles = await readDirRecursive(fullPath, relativePath);
      files.push(...subFiles);
    } else {
      files.push(relativePath);
    }
  }

  return files;
}

/**
 * 删除文件
 * @param {string} filePath - 文件路径
 * @returns {Promise<void>}
 */
async function removeFile(filePath) {
  await fs.remove(filePath);
}

/**
 * 获取文件统计信息
 * @param {string} filePath - 文件路径
 * @returns {Promise<Object>} 统计信息
 */
async function stat(filePath) {
  return await fs.stat(filePath);
}

/**
 * 获取文件大小
 * @param {string} filePath - 文件路径
 * @returns {Promise<number>} 文件大小（字节）
 */
async function getFileSize(filePath) {
  const stats = await fs.stat(filePath);
  return stats.size;
}

/**
 * 获取文件hash
 * @param {string} filePath - 文件路径
 * @param {string} algorithm - hash算法
 * @returns {Promise<string>} hash值
 */
async function getFileHash(filePath, algorithm = 'md5') {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash(algorithm);
    const stream = fs.createReadStream(filePath);

    stream.on('data', (data) => hash.update(data));
    stream.on('end', () => resolve(hash.digest('hex')));
    stream.on('error', reject);
  });
}

/**
 * 获取目录大小
 * @param {string} dirPath - 目录路径
 * @returns {Promise<number>} 目录大小（字节）
 */
async function getDirSize(dirPath) {
  const files = await readDirRecursive(dirPath);
  let totalSize = 0;

  for (const file of files) {
    totalSize += await getFileSize(path.join(dirPath, file));
  }

  return totalSize;
}

/**
 * 格式化文件大小
 * @param {number} bytes - 字节数
 * @returns {string} 格式化后的大小
 */
function formatFileSize(bytes) {
  if (bytes === 0) return '0 Bytes';

  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));

  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

/**
 * 获取文件扩展名
 * @param {string} fileName - 文件名
 * @returns {string} 扩展名
 */
function getFileExtension(fileName) {
  return path.extname(fileName);
}

/**
 * 获取文件名（不含扩展名）
 * @param {string} fileName - 文件名
 * @returns {string} 文件名（不含扩展名）
 */
function getFileNameWithoutExtension(fileName) {
  return path.basename(fileName, getFileExtension(fileName));
}

/**
 * 将路径转换为相对路径
 * @param {string} from - 源路径
 * @param {string} to - 目标路径
 * @returns {string} 相对路径
 */
function getRelativePath(from, to) {
  return path.relative(from, to);
}

/**
 * 安全地解析路径
 * @param {...string} paths - 路径片段
 * @returns {string} 解析后的路径
 */
function resolvePath(...paths) {
  return path.resolve(...paths);
}

/**
 * 创建临时文件
 * @param {string} prefix - 前缀
 * @param {string} suffix - 后缀
 * @returns {Promise<string>} 临时文件路径
 */
async function createTempFile(prefix = 'tmp-', suffix = '') {
  const tempDir = require('os').tmpdir();
  const tempPath = path.join(tempDir, `${prefix}${Date.now()}${suffix}`);
  await fs.ensureDir(path.dirname(tempPath));
  return tempPath;
}

/**
 * 清空目录（保留目录本身）
 * @param {string} dirPath - 目录路径
 * @returns {Promise<void>}
 */
async function clearDir(dirPath) {
  const files = await readDir(dirPath);
  for (const file of files) {
    await fs.remove(path.join(dirPath, file));
  }
}

module.exports = {
  ensureDir,
  removeDir,
  copyDir,
  readFile,
  writeFile,
  appendFile,
  exists,
  readDir,
  readDirRecursive,
  removeFile,
  stat,
  getFileSize,
  getFileHash,
  getDirSize,
  formatFileSize,
  getFileExtension,
  getFileNameWithoutExtension,
  getRelativePath,
  resolvePath,
  createTempFile,
  clearDir
};
