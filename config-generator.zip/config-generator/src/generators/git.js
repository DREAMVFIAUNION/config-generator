/**
 * Git初始化生成器
 * 
 * 处理Git仓库的初始化和配置
 * 
 * @author DRAMVFIA UNION
 */

'use strict';

const { exec } = require('child_process');
const path = require('path');
const fs = require('fs-extra');
const chalk = require('chalk');
const ora = require('ora');

/**
 * 初始化Git仓库
 * @param {string} projectDir - 项目目录
 * @returns {Promise<void>}
 */
async function initGit(projectDir) {
  return new Promise((resolve, reject) => {
    const spinner = ora('正在初始化Git仓库...').start();

    const gitProcess = exec('git init', {
      cwd: projectDir,
      stdio: 'pipe',
      encoding: 'utf-8'
    });

    gitProcess.on('close', (code) => {
      if (code === 0) {
        spinner.succeed('Git仓库初始化完成！');
        
        // 配置Git用户信息（如果有的话）
        configureGit(projectDir).then(() => {
          resolve();
        }).catch(() => {
          // 配置失败不阻碍初始化
          resolve();
        });
      } else {
        spinner.fail('Git仓库初始化失败！');
        reject(new Error(`git init 失败，退出码：${code}`));
      }
    });

    gitProcess.on('error', (error) => {
      spinner.fail('Git仓库初始化失败！');
      reject(error);
    });
  });
}

/**
 * 配置Git用户信息
 * @param {string} projectDir - 项目目录
 * @returns {Promise<void>}
 */
async function configureGit(projectDir) {
  return new Promise((resolve) => {
    // 检查全局Git配置
    exec('git config --global user.name', {
      cwd: projectDir,
      stdio: 'pipe'
    }, (error, stdout) => {
      if (error || !stdout.trim()) {
        console.log(chalk.yellow('\n⚠️  Git用户信息未配置'));
        console.log(chalk.gray('  请运行以下命令配置Git用户信息：'));
        console.log(chalk.cyan('  git config --global user.name "你的名字"'));
        console.log(chalk.cyan('  git config --global user.email "你的邮箱"'));
        console.log();
        resolve();
        return;
      }
      
      // 配置本地仓库
      exec(`git config local.user.name "${stdout.trim()}"`, {
        cwd: projectDir,
        stdio: 'pipe'
      });
      
      exec('git config --global user.email', {
        cwd: projectDir,
        stdio: 'pipe'
      }, (error, email) => {
        if (!error && email.trim()) {
          exec(`git config local.user.email "${email.trim()}"`, {
            cwd: projectDir,
            stdio: 'pipe'
          });
        }
        resolve();
      });
    });
  });
}

/**
 * 创建初始提交
 * @param {string} projectDir - 项目目录
 * @param {string} message - 提交消息
 * @returns {Promise<void>}
 */
async function createInitialCommit(projectDir, message = 'feat: initial commit') {
  return new Promise((resolve, reject) => {
    const spinner = ora('正在创建初始提交...').start();

    // 添加所有文件
    const addProcess = exec('git add .', {
      cwd: projectDir,
      stdio: 'pipe'
    });

    addProcess.on('close', (addCode) => {
      if (addCode !== 0) {
        spinner.fail('添加文件到暂存区失败！');
        reject(new Error('git add 失败'));
        return;
      }

      // 创建提交
      const commitProcess = exec(`git commit -m "${message}"`, {
        cwd: projectDir,
        stdio: 'pipe'
      });

      commitProcess.on('close', (code) => {
        if (code === 0) {
          spinner.succeed('初始提交创建成功！');
          resolve();
        } else {
          spinner.warn('初始提交创建失败（可能是因为没有更改）');
          resolve(); // 提交失败不阻碍流程
        }
      });

      commitProcess.on('error', (error) => {
        spinner.warn('初始提交创建失败');
        resolve();
      });
    });

    addProcess.on('error', (error) => {
      spinner.warn('添加文件失败');
      resolve();
    });
  });
}

/**
 * 创建远程仓库并推送
 * @param {string} projectDir - 项目目录
 * @param {string} remoteUrl - 远程仓库URL
 * @param {string} branch - 分支名称
 * @returns {Promise<void>}
 */
async function addRemoteAndPush(projectDir, remoteUrl, branch = 'main') {
  return new Promise((resolve, reject) => {
    const spinner = ora('正在添加远程仓库...').start();

    // 添加远程仓库
    const addRemoteProcess = exec(`git remote add origin ${remoteUrl}`, {
      cwd: projectDir,
      stdio: 'pipe'
    });

    addRemoteProcess.on('close', (code) => {
      if (code !== 0) {
        // 远程可能已存在
        spinner.warn('远程仓库可能已存在');
      } else {
        spinner.succeed('远程仓库添加成功！');
      }

      // 推送到远程
      const pushSpinner = ora(`正在推送到 ${branch} 分支...`).start();
      
      const pushProcess = exec(`git push -u origin ${branch}`, {
        cwd: projectDir,
        stdio: 'pipe'
      });

      pushProcess.on('close', (pushCode) => {
        if (pushCode === 0) {
          pushSpinner.succeed('推送成功！');
          resolve();
        } else {
          pushSpinner.fail('推送失败！');
          reject(new Error('git push 失败'));
        }
      });

      pushProcess.on('error', (error) => {
        pushSpinner.fail('推送失败！');
        reject(error);
      });
    });

    addRemoteProcess.on('error', (error) => {
      spinner.fail('添加远程仓库失败！');
      reject(error);
    });
  });
}

/**
 * 创建.gitignore文件
 * @param {string} projectDir - 项目目录
 * @returns {Promise<void>}
 */
async function createGitignore(projectDir) {
  const gitignorePath = path.join(projectDir, '.gitignore');
  
  const gitignoreContent = getDefaultGitignore();
  
  await fs.writeFile(gitignorePath, gitignoreContent);
}

/**
 * 获取默认的.gitignore内容
 * @returns {string} .gitignore内容
 */
function getDefaultGitignore() {
  return `# 依赖目录
node_modules/

# 构建输出
dist/
build/
coverage/

# 环境变量
.env
.env.local
.env.*.local

# 日志文件
logs/
*.log
npm-debug.log*
yarn-debug.log*
yarn-error.log*
pnpm-debug.log*

# 编辑器配置
.idea/
.vscode/
*.swp
*.swo
*~

# 操作系统文件
.DS_Store
Thumbs.db
*.DS_Store

# 测试输出
.nyc_output/

# TypeScript
*.tsbuildinfo

# ESLint
.eslintcache

# Parcel
.cache/
.parcel-cache/

# 临时文件
tmp/
temp/

# 难搞的文件
*.local
`;
}

/**
 * 检查Git是否可用
 * @returns {Promise<boolean>}
 */
async function checkGitAvailable() {
  return new Promise((resolve) => {
    exec('git --version', {
      stdio: 'pipe'
    }, (error) => {
      resolve(!error);
    });
  });
}

/**
 * 获取Git状态
 * @param {string} projectDir - 项目目录
 * @returns {Promise<Object>}
 */
async function getGitStatus(projectDir) {
  return new Promise((resolve) => {
    exec('git status --porcelain', {
      cwd: projectDir,
      stdio: 'pipe'
    }, (error, stdout) => {
      if (error) {
        resolve({ error: true, status: null });
        return;
      }

      const status = stdout.trim();
      const files = status ? status.split('\n').filter(line => line.trim()) : [];
      
      resolve({
        error: false,
        hasChanges: files.length > 0,
        files: files
      });
    });
  });
}

/**
 * 创建GitHub Actions工作流
 * @param {string} projectDir - 项目目录
 * @param {Object} config - 项目配置
 * @returns {Promise<void>}
 */
async function createGitHubWorkflow(projectDir, config) {
  const workflowsDir = path.join(projectDir, '.github', 'workflows');
  await fs.ensureDir(workflowsDir);

  const workflowContent = getGitHubWorkflowContent(config);
  await fs.writeFile(
    path.join(workflowsDir, 'node.js.yml'),
    workflowContent
  );
}

/**
 * 获取GitHub Actions工作流配置
 * @param {Object} config - 项目配置
 * @returns {string} 工作流配置内容
 */
function getGitHubWorkflowContent(config) {
  return `name: Node.js CI

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

jobs:
  build:
    runs-on: ubuntu-latest

    strategy:
      matrix:
        node-version: [18.x, 20.x]

    steps:
      - uses: actions/checkout@v4

      - name: Use Node.js \${{ matrix.node-version }}
        uses: actions/setup-node@v4
        with:
          node-version: \${{ matrix.node-version }}
          cache: 'npm'

      - name: Install dependencies
        run: npm ci

      - name: Lint
        run: npm run lint

      - name: Test
        run: npm test -- --coverage
`;
}

module.exports = {
  initGit,
  createInitialCommit,
  addRemoteAndPush,
  createGitignore,
  checkGitAvailable,
  getGitStatus,
  createGitHubWorkflow
};
