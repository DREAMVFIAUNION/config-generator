/**
 * 项目结构生成器
 * 
 * 根据配置生成项目目录结构
 * 
 * @author DRAMVFIA UNION
 */

'use strict';

const fs = require('fs-extra');
const path = require('path');

/**
 * 生成项目目录结构
 * @param {string} projectDir - 项目目录
 * @param {Object} config - 项目配置
 * @returns {Promise<void>}
 */
async function projectStructure(projectDir, config) {
  // 创建基础目录结构
  const directories = [
    'src',
    'tests'
  ];

  // 根据项目类型添加额外目录
  if (config.projectType === 'api' || config.projectType === 'fullstack') {
    directories.push(
      'src/routes',
      'src/controllers',
      'src/models',
      'src/services',
      'src/middlewares',
      'src/utils',
      'src/config',
      'public'
    );
  } else if (config.projectType === 'cli') {
    directories.push(
      'src/commands',
      'src/utils',
      'src/templates',
      'bin'
    );
  }

  // TypeScript项目添加类型目录
  if (config.typescript) {
    directories.push('src/types');
  }

  // 创建目录
  for (const dir of directories) {
    const dirPath = path.join(projectDir, dir);
    await fs.ensureDir(dirPath);
  }

  // 创建基础文件
  await createBaseFiles(projectDir, config);
  
  // 根据框架创建入口文件
  await createEntryFile(projectDir, config);
  
  // 根据项目类型创建结构文件
  await createStructureFiles(projectDir, config);
}

/**
 * 创建基础配置文件
 * @param {string} projectDir - 项目目录
 * @param {Object} config - 项目配置
 */
async function createBaseFiles(projectDir, config) {
  // 创建.gitignore
  const gitignoreContent = getGitignoreContent();
  await fs.writeFile(path.join(projectDir, '.gitignore'), gitignoreContent);

  // 创建README.md
  const readmeContent = getReadmeContent(config);
  await fs.writeFile(path.join(projectDir, 'README.md'), readmeContent);

  // 创建.editorconfig
  const editorconfigContent = getEditorconfigContent();
  await fs.writeFile(path.join(projectDir, '.editorconfig'), editorconfigContent);

  // 创建.env.example
  const envExample = getEnvExample(config);
  await fs.writeFile(path.join(projectDir, '.env.example'), envExample);
}

/**
 * 创建入口文件
 * @param {string} projectDir - 项目目录
 * @param {Object} config - 项目配置
 */
async function createEntryFile(projectDir, config) {
  const ext = config.typescript ? 'ts' : 'js';
  
  let entryContent;
  
  if (config.typescript) {
    entryContent = getTypeScriptEntry(config);
  } else {
    entryContent = getJavaScriptEntry(config);
  }

  await fs.writeFile(path.join(projectDir, `src/index.${ext}`), entryContent);
}

/**
 * 获取TypeScript入口文件内容
 * @param {Object} config - 项目配置
 * @returns {string} 文件内容
 */
function getTypeScriptEntry(config) {
  if (config.framework === 'express') {
    return `/**
 * Express应用入口文件
 * 
 * @version 1.0.0
 */

import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import morgan from 'morgan';
import dotenv from 'dotenv';

// 加载环境变量
dotenv.config();

// 导入路由
import indexRouter from './routes/index';
import userRouter from './routes/user';

// 导入中间件
import { errorHandler } from './middlewares/errorHandler';
import { notFoundHandler } from './middlewares/notFound';

// 创建Express应用
const app = express();
const PORT = process.env.PORT || 3000;

// 中间件配置
app.use(helmet());
app.use(cors());
app.use(compression());
app.use(morgan('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// 路由配置
app.use('/', indexRouter);
app.use('/users', userRouter);

// 404处理
app.use(notFoundHandler);

// 错误处理
app.use(errorHandler);

// 启动服务器
app.listen(PORT, () => {
  console.log(\`🚀 服务器运行在 http://localhost:\${PORT}\`);
  console.log(\`📝 环境: \${process.env.NODE_ENV || 'development'}\`);
});

export default app;
`;
  } else if (config.framework === 'koa') {
    return `/**
 * Koa应用入口文件
 * 
 * @version 1.0.0
 */

import Koa from 'koa';
import Router from 'koa-router';
import cors from 'koa-cors';
import bodyParser from 'koa-bodyparser';
import helmet from 'koa-helmet';
import compress from 'koa-compress';
import dotenv from 'dotenv';

// 加载环境变量
dotenv.config();

// 创建Koa应用
const app = new Koa();
const PORT = process.env.PORT || 3000;

// 中间件配置
app.use(helmet());
app.use(cors());
app.use(compress());
app.use(bodyParser());

// 日志中间件
app.use(async (ctx, next) => {
  const start = Date.now();
  await next();
  const ms = Date.now() - start;
  console.log(\`\${ctx.method} \${ctx.url} - \${ms}ms\`);
});

// 路由配置
const router = new Router();

router.get('/', async (ctx) => {
  ctx.body = {
    message: '欢迎使用Koa API服务',
    version: '1.0.0',
    timestamp: new Date().toISOString()
  };
});

router.get('/health', async (ctx) => {
  ctx.body = { status: 'ok' };
});

// 注册路由
app.use(router.routes());
app.use(router.allowedMethods());

// 启动服务器
app.listen(PORT, () => {
  console.log(\`🚀 Koa服务器运行在 http://localhost:\${PORT}\`);
  console.log(\`📝 环境: \${process.env.NODE_ENV || 'development'}\`);
});

export default app;
`;
  } else if (config.framework === 'nestjs') {
    return `/**
 * NestJS应用入口文件
 * 
 * @version 1.0.0
 */

import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import dotenv from 'dotenv';

async function bootstrap() {
  // 加载环境变量
  dotenv.config();

  const app = await NestFactory.create(AppModule);
  const PORT = process.env.PORT || 3000;

  // 启用CORS
  app.enableCors();

  await app.listen(PORT);
  console.log(\`🚀 NestJS应用运行在 http://localhost:\${PORT}\`);
  console.log(\`📝 环境: \${process.env.NODE_ENV|| 'development'}\`);
}

bootstrap();
`;
  }

  // 默认Express入口
  return `/**
 * 应用入口文件
 * 
 * @version 1.0.0
 */

import express from 'express';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// 基础中间件
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// 根路由
app.get('/', (req, res) => {
  res.json({
    message: '欢迎使用Node.js项目',
    version: '1.0.0'
  });
});

// 启动服务器
app.listen(PORT, () => {
  console.log(\`🚀 服务器运行在 http://localhost:\${PORT}\`);
});

export default app;
`;
}

/**
 * 获取JavaScript入口文件内容
 * @param {Object} config - 项目配置
 * @returns {string} 文件内容
 */
function getJavaScriptEntry(config) {
  if (config.framework === 'express') {
    return `/**
 * Express应用入口文件
 * 
 * @version 1.0.0
 */

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const morgan = require('morgan');
require('dotenv').config();

// 导入路由
const indexRouter = require('./routes/index');
const userRouter = require('./routes/user');

// 导入中间件
const { errorHandler } = require('./middlewares/errorHandler');
const { notFoundHandler } = require('./middlewares/notFound');

const app = express();
const PORT = process.env.PORT || 3000;

// 中间件配置
app.use(helmet());
app.use(cors());
app.use(compression());
app.use(morgan('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// 路由配置
app.use('/', indexRouter);
app.use('/users', userRouter);

// 404处理
app.use(notFoundHandler);

// 错误处理
app.use(errorHandler);

// 启动服务器
app.listen(PORT, () => {
  console.log(\`🚀 服务器运行在 http://localhost:\${PORT}\`);
  console.log(\`📝 环境: \${process.env.NODE_ENV || 'development'}\`);
});

module.exports = app;
`;
  } else if (config.framework === 'koa') {
    return `/**
 * Koa应用入口文件
 * 
 * @version 1.0.0
 */

const Koa = require('koa');
const Router = require('koa-router');
const cors = require('koa-cors');
const bodyParser = require('koa-bodyparser');
const helmet = require('koa-helmet');
const compress = require('koa-compress');
require('dotenv').config();

const app = new Koa();
const PORT = process.env.PORT || 3000;

// 中间件配置
app.use(helmet());
app.use(cors());
app.use(compress());
app.use(bodyParser());

// 日志中间件
app.use(async (ctx, next) => {
  const start = Date.now();
  await next();
  const ms = Date.now() - start;
  console.log(\`\${ctx.method} \${ctx.url} - \${ms}ms\`);
});

// 路由配置
const router = new Router();

router.get('/', async (ctx) => {
  ctx.body = {
    message: '欢迎使用Koa API服务',
    version: '1.0.0',
    timestamp: new Date().toISOString()
  };
});

router.get('/health', async (ctx) => {
  ctx.body = { status: 'ok' };
});

// 注册路由
app.use(router.routes());
app.use(router.allowedMethods());

// 启动服务器
app.listen(PORT, () => {
  console.log(\`🚀 Koa服务器运行在 http://localhost:\${PORT}\`);
  console.log(\`📝 环境: \${process.env.NODE_ENV || 'development'}\`);
});

module.exports = app;
`;
  } else if (config.framework === 'nestjs') {
    return `/**
 * NestJS应用入口文件
 * 
 * @version 1.0.0
 */

const { NestFactory } = require('@nestjs/core');
const { AppModule } = require('./app.module');
require('dotenv').config();

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  const PORT = process.env.PORT || 3000;

  app.enableCors();
  await app.listen(PORT);
  console.log(\`🚀 NestJS应用运行在 http://localhost:\${PORT}\`);
}

bootstrap();
`;
  }

  // CLI工具入口
  if (config.projectType === 'cli') {
    return `/**
 * CLI工具入口文件
 * 
 * @version 1.0.0
 */

const { Command } = require('commander');
const packageJson = require('../package.json');

const program = new Command();

program
  .name(packageJson.name)
  .description(packageJson.description)
  .version(packageJson.version);

// 添加子命令
program
  .command('start')
  .description('启动服务')
  .action(() => {
    console.log('启动服务...');
  });

program
  .command('init')
  .description('初始化项目')
  .action(() => {
    console.log('初始化项目...');
  });

// 解析命令行参数
program.parse(process.argv);

// 显示帮助信息
if (!process.argv.slice(2).length) {
  program.outputHelp();
}
`;
  }

  // 默认入口
  return `/**
 * 应用入口文件
 * 
 * @version 1.0.0
 */

require('dotenv').config();

const app = require('express')();
const PORT = process.env.PORT || 3000;

app.get('/', (req, res) => {
  res.json({
    message: '欢迎使用Node.js项目',
    version: '1.0.0'
  });
});

app.listen(PORT, () => {
  console.log(\`🚀 服务器运行在 http://localhost:\${PORT}\`);
});

module.exports = app;
`;
}

/**
 * 创建结构文件（路由、中间件等）
 * @param {string} projectDir - 项目目录
 * @param {Object} config - 项目配置
 */
async function createStructureFiles(projectDir, config) {
  const ext = config.typescript ? 'ts' : 'js';
  
  // 创建示例路由
  await fs.writeFile(
    path.join(projectDir, `src/routes/index.${ext}`),
    getIndexRoute(config)
  );
  
  await fs.writeFile(
    path.join(projectDir, `src/routes/user.${ext}`),
    getUserRoute(config)
  );

  // 创建示例控制器
  await fs.writeFile(
    path.join(projectDir, `src/controllers/userController.${ext}`),
    getUserController(config)
  );

  // 创建中间件
  await fs.writeFile(
    path.join(projectDir, `src/middlewares/errorHandler.${ext}`),
    getErrorHandler(config)
  );
  
  await fs.writeFile(
    path.join(projectDir, `src/middlewares/notFound.${ext}`),
    getNotFoundHandler(config)
  );

  // 创建示例服务
  await fs.writeFile(
    path.join(projectDir, `src/services/userService.${ext}`),
    getUserService(config)
  );

  // 创建配置文件
  await fs.writeFile(
    path.join(projectDir, `src/config/index.${ext}`),
    getConfigFile(config)
  );

  // 创建工具文件
  await fs.writeFile(
    path.join(projectDir, `src/utils/logger.${ext}`),
    getLoggerFile(config)
  );

  // 创建测试文件
  await fs.writeFile(
    path.join(projectDir, `tests/sample.test.${ext}`),
    getSampleTest(config)
  );
}

/**
 * 获取.gitignore内容
 * @returns {string} .gitignore内容
 */
function getGitignoreContent() {
  return `# 依赖目录
node_modules/

# 构建输出
dist/
build/

# 环境变量文件
.env
.env.local
.env.*.local

# 日志文件
logs/
*.log
npm-debug.log*
yarn-debug.log*
yarn-error.log*

# 编辑器配置
.idea/
.vscode/
*.swp
*.swo
*~

# 操作系统文件
.DS_Store
Thumbs.db

# 测试覆盖率
coverage/

# 临时文件
tmp/
temp/

# TypeScript
*.tsbuildinfo

# ESLint
.eslintcache

# 缓存目录
.cache/
.parcel-cache/
`;
}

/**
 * 获取README.md内容
 * @param {Object} config - 项目配置
 * @returns {string} README内容
 */
function getReadmeContent(config) {
  return `# ${config.projectName}

${config.projectDescription || 'A Node.js project'}

## 功能特性

- 基于 ${config.framework} 构建
${config.typescript ? '- 使用 TypeScript 开发' : ''}
${config.eslint ? '- ESLint 代码规范检查' : ''}
${config.prettier ? '- Prettier 代码格式化' : ''}
${config.jest ? '- Jest 测试框架' : ''}
${config.vitest ? '- Vitest 测试框架' : ''}

## 快速开始

### 安装依赖

\`\`\`bash
npm install
\`\`\`

### 开发模式

\`\`\`bash
npm run dev
\`\`\`

### 生产模式

\`\`\`bash
npm run build
npm start
\`\`\`

### 运行测试

\`\`\`bash
npm test
\`\`\`

### 代码检查

\`\`\`bash
# ESLint检查
npm run lint

# 代码格式化
npm run format
\`\`\`

## 项目结构

\`\`\`
${config.projectName}/
├── src/
│   ├── controllers/    # 控制器层
│   ├── routes/         # 路由定义
│   ├── models/         # 数据模型
│   ├── services/       # 业务逻辑
│   ├── middlewares/    # 中间件
│   ├── utils/          # 工具函数
│   └── config/         # 配置文件
├── tests/              # 测试文件
├── public/             # 静态资源
├── .env.example        # 环境变量示例
└── package.json
\`\`\`

## 环境变量

请复制 \`.env.example\` 文件为 \`.env\` 并配置相应变量。

## License

MIT
`;
}

/**
 * 获取.editorconfig内容
 * @returns {string} .editorconfig内容
 */
function getEditorconfigContent() {
  return `# EditorConfig is awesome: https://EditorConfig.org

root = true

[*]
indent_style = space
indent_size = 2
end_of_line = lf
charset = utf-8
trim_trailing_whitespace = true
insert_final_newline = true

[*.md]
trim_trailing_whitespace = false

[*.{js,ts}]
indent_size = 2

[*.py]
indent_size = 4
`;
}

/**
 * 获取.env.example内容
 * @param {Object} config - 项目配置
 * @returns {string} .env.example内容
 */
function getEnvExample(config) {
  return `# 服务器配置
PORT=3000
NODE_ENV=development

# 数据库配置（根据需要修改）
DB_HOST=localhost
DB_PORT=5432
DB_NAME=mydb
DB_USER=postgres
DB_PASSWORD=

# 其他配置
JWT_SECRET=your-jwt-secret-key
API_KEY=your-api-key
`;
}

// 辅助函数获取各种模板内容
function getIndexRoute(config) {
  const ext = config.typescript ? 'ts' : 'js';
  return `/**
 * 首页路由
 * 
 * @version 1.0.0
 */

const express = require('express');
const router = express.Router();

/**
 * @route GET /
 * @description 获取首页信息
 */
router.get('/', (req, res) => {
  res.json({
    success: true,
    message: '欢迎使用API服务',
    version: '1.0.0',
    timestamp: new Date().toISOString()
  });
});

/**
 * @route GET /health
 * @description 健康检查
 */
router.get('/health', (req, res) => {
  res.json({ status: 'ok' });
});

module.exports = router;
`;
}

function getUserRoute(config) {
  const ext = config.typescript ? 'ts' : 'js';
  return `/**
 * 用户路由
 * 
 * @version 1.0.0
 */

const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');

/**
 * @route GET /users
 * @description 获取用户列表
 */
router.get('/', userController.getUsers);

/**
 * @route GET /users/:id
 * @description 获取单个用户
 */
router.get('/:id', userController.getUserById);

/**
 * @route POST /users
 * @description 创建用户
 */
router.post('/', userController.createUser);

/**
 * @route PUT /users/:id
 * @description 更新用户
 */
router.put('/:id', userController.updateUser);

/**
 * @route DELETE /users/:id
 * @description 删除用户
 */
router.delete('/:id', userController.deleteUser);

module.exports = router;
`;
}

function getUserController(config) {
  return `/**
 * 用户控制器
 * 
 * @version 1.0.0
 */

const userService = require('../services/userService');

/**
 * 获取所有用户
 */
exports.getUsers = async (req, res) => {
  try {
    const users = await userService.getAllUsers();
    res.json({
      success: true,
      data: users
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 获取单个用户
 */
exports.getUserById = async (req, res) => {
  try {
    const user = await userService.getUserById(req.params.id);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: '用户不存在'
      });
    }
    res.json({
      success: true,
      data: user
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 创建用户
 */
exports.createUser = async (req, res) => {
  try {
    const user = await userService.createUser(req.body);
    res.status(201).json({
      success: true,
      data: user
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 更新用户
 */
exports.updateUser = async (req, res) => {
  try {
    const user = await userService.updateUser(req.params.id, req.body);
    res.json({
      success: true,
      data: user
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
};

/**
 * 删除用户
 */
exports.deleteUser = async (req, res) => {
  try {
    await userService.deleteUser(req.params.id);
    res.json({
success: true,
      message: '用户删除成功'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};
`;
}

function getErrorHandler(config) {
  return `/**
 * 错误处理中间件
 * 
 * @version 1.0.0
 */

/**
 * 错误处理中间件
 */
exports.errorHandler = (err, req, res, next) => {
  console.error('错误:', err);

  // 默认错误状态码
  const statusCode = err.statusCode || 500;
  const message = err.message || '服务器内部错误';

  res.status(statusCode).json({
    success: false,
    message: message,
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
  });
};
`;
}

function getNotFoundHandler(config) {
  return `/**
 * 404处理中间件
 * 
 * @version 1.0.0
 */

/**
 * 404未找到中间件
 */
exports.notFoundHandler = (req, res) => {
  res.status(404).json({
    success: false,
    message: '请求的资源不存在',
    path: req.originalUrl
  });
};
`;
}

function getUserService(config) {
  return `/**
 * 用户服务
 * 
 * @version 1.0.0
 */

// 模拟数据
let users = [
  { id: 1, name: '张三', email: 'zhangsan@example.com' },
  { id: 2, name: '李四', email: 'lisi@example.com' }
];

/**
 * 获取所有用户
 */
exports.getAllUsers = async () => {
  return users;
};

/**
 * 根据ID获取用户
 */
exports.getUserById = async (id) => {
  return users.find(user => user.id === parseInt(id));
};

/**
 * 创建用户
 */
exports.createUser = async (userData) => {
  const newUser = {
    id: users.length + 1,
    ...userData
  };
  users.push(newUser);
  return newUser;
};

/**
 * 更新用户
 */
exports.updateUser = async (id, userData) => {
  const index = users.findIndex(user => user.id === parseInt(id));
  if (index === -1) {
    throw new Error('用户不存在');
  }
  users[index] = { ...users[index], ...userData };
  return users[index];
};

/**
 * 删除用户
 */
exports.deleteUser = async (id) => {
  const index = users.findIndex(user => user.id === parseInt(id));
  if (index === -1) {
    throw new Error('用户不存在');
  }
  users.splice(index, 1);
};
`;
}

function getConfigFile(config) {
  return `/**
 * 应用配置文件
 * 
 * @version 1.0.0
 */

module.exports = {
  // 服务器配置
  server: {
    port: process.env.PORT || 3000,
    env: process.env.NODE_ENV || 'development'
  },

  // 数据库配置
  database: {
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT || 5432,
    name: process.env.DB_NAME || 'mydb',
    user: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD || ''
  },

  // JWT配置
  jwt: {
    secret: process.env.JWT_SECRET || 'your-jwt-secret',
    expiresIn: '24h'
  },

  // 其他配置
  api: {
    prefix: '/api'
  }
};
`;
}

function getLoggerFile(config) {
  return `/**
 * 日志工具
 * 
 * @version 1.0.0
 */

const winston = require('winston');
const path = require('path');

// 日志格式
const logFormat = winston.format.combine(
  winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
  winston.format.errors({ stack: true }),
  winston.format.printf(({ level, message, timestamp, stack }) => {
    return \`\${timestamp} [\${level.toUpperCase()}]: \${stack || message}\`;
  })
);

// 创建logger实例
const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: logFormat,
  transports: [
    // 控制台输出
    new winston.transports.Console({
      format: winston.format.combine(
        winston.format.colorize(),
        logFormat
      )
    }),
    // 错误日志
    new winston.transports.File({
      filename: path.join(__dirname, '../../logs/error.log'),
      level: 'error'
    }),
    // 组合日志
    new winston.transports.File({
      filename: path.join(__dirname, '../../logs/combined.log')
    })
  ]
});

module.exports = logger;
`;
}

function getSampleTest(config) {
  return `/**
 * 示例测试文件
 * 
 * @version 1.0.0
 */

describe('示例测试', () => {
  test('应该通过基本测试', () => {
    expect(1 + 1).toBe(2);
  });

  test('应该正确处理数组', () => {
    const arr = [1, 2, 3];
    expect(arr).toHaveLength(3);
    expect(arr).toContain(2);
  });

  test('应该正确处理对象', () => {
    const obj = { name: '测试', value: 42 };
    expect(obj).toHaveProperty('name');
    expect(obj.name).toBe('测试');
  });
});

describe('异步测试', () => {
  test('应该正确处理Promise', async () => {
    const data = await Promise.resolve('异步数据');
    expect(data).toBe('异步数据');
  });

  test('应该正确处理async/await', async () => {
    const result = await new Promise(resolve => setTimeout(() => resolve('完成'), 10));
    expect(result).toBe('完成');
  });
});
`;
}

module.exports = {
  projectStructure
};
