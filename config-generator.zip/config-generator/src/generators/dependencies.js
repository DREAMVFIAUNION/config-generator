/**
 * 依赖安装生成器
 * 
 * 处理依赖包的安装逻辑
 * 
 * @author DRAMVFIA UNION
 */

'use strict';

const { exec } = require('child_process');
const path = require('path');
const fs = require('fs-extra');
const ora = require('ora');
const chalk = require('chalk');

/**
 * 安装项目依赖
 * @param {string} projectDir - 项目目录
 * @param {Object} config - 项目配置
 * @returns {Promise<void>}
 */
async function installDependencies(projectDir, config) {
  const packageManager = config.packageManager || 'npm';
  
  // 根据包管理器选择安装命令
  const installCommand = getInstallCommand(packageManager);
  
  // 创建logs目录
  await fs.ensureDir(path.join(projectDir, 'logs'));

  // 执行安装
  await executeInstall(projectDir, installCommand);
}

/**
 * 获取包管理器安装命令
 * @param {string} packageManager - 包管理器名称
 * @returns {Object} 命令配置
 */
function getInstallCommand(packageManager) {
  const commands = {
    npm: {
      install: 'npm install',
      ci: 'npm ci',
      addDev: 'npm install -D',
      add: 'npm install',
      run: 'npm run'
    },
    yarn: {
      install: 'yarn install',
      ci: 'yarn install --frozen-lockfile',
      addDev: 'yarn add -D',
      add: 'yarn add',
      run: 'yarn'
    },
    pnpm: {
      install: 'pnpm install',
      ci: 'pnpm install --frozen-lockfile',
      addDev: 'pnpm add -D',
      add: 'pnpm add',
      run: 'pnpm'
    }
  };

  return commands[packageManager] || commands.npm;
}

/**
 * 执行依赖安装
 * @param {string} projectDir - 项目目录
 * @param {Object} commands - 命令配置
 */
async function executeInstall(projectDir, commands) {
  return new Promise((resolve, reject) => {
    const spinner = ora('正在初始化依赖安装...').start();
    
    // 获取package.json中的依赖信息
    const packageJsonPath = path.join(projectDir, 'package.json');
    
    let installProcess;
    
    // 检查是否有lock文件来决定使用npm install还是npm ci
    if (fs.existsSync(path.join(projectDir, 'package-lock.json'))) {
      installProcess = exec(commands.ci, {
        cwd: projectDir,
        stdio: 'pipe',
        encoding: 'utf-8'
      });
      spinner.text = '正在使用 npm ci 安装依赖...';
    } else {
      installProcess = exec(commands.install, {
        cwd: projectDir,
        stdio: 'pipe',
        encoding: 'utf-8'
      });
      spinner.text = '正在安装依赖包...';
    }

    let output = '';
    let errorOutput = '';

    installProcess.stdout.on('data', (data) => {
      output += data;
      // 更新spinner文字（只显示最后一行）
      const lines = output.trim().split('\n');
      if (lines.length > 0) {
        const lastLine = lines[lines.length - 1].trim();
        if (lastLine) {
          spinner.text = lastLine.substring(0, 50);
        }
      }
    });

    installProcess.stderr.on('data', (data) => {
      errorOutput += data;
    });

    installProcess.on('close', (code) => {
      if (code === 0) {
        spinner.succeed('依赖安装完成！');
        
        // 显示安装摘要
        showInstallSummary(projectDir, commands);
        
        resolve();
      } else {
        spinner.warn('依赖安装遇到一些问题，但已尽量安装。');
        
        // 显示错误信息
        if (errorOutput) {
          console.log(chalk.red('错误信息：'));
          console.log(errorOutput.substring(0, 500));
        }
        
        // 提示用户手动安装
        console.log(chalk.yellow('\n💡 建议手动运行以下命令：'));
        console.log(chalk.cyan(`  cd ${path.basename(projectDir)}`));
        console.log(chalk.cyan(`  ${commands.install}`));
        
        resolve(); // 即使失败也继续
      }
    });

    // 超时处理（30分钟）
    setTimeout(() => {
      if (!installProcess.killed) {
        installProcess.kill();
        spinner.warn('安装超时，请手动安装依赖。');
        console.log(chalk.yellow('\n💡 请手动运行以下命令：'));
        console.log(chalk.cyan(`  cd ${path.basename(projectDir)}`));
        console.log(chalk.cyan(`  ${commands.install}`));
        resolve();
      }
    }, 30 * 60 * 1000);
  });
}

/**
 * 显示安装摘要
 * @param {string} projectDir - 项目目录
 * @param {Object} commands - 命令配置
 */
function showInstallSummary(projectDir, commands) {
  // 读取package.json获取依赖信息
  const packageJsonPath = path.join(projectDir, 'package.json');
  const packageJson = fs.readJsonSync(packageJsonPath);
  
  const depCount = Object.keys(packageJson.dependencies || {}).length;
  const devDepCount = Object.keys(packageJson.devDependencies || {}).length;
  
  console.log(chalk.cyan('\n📦 依赖安装摘要：'));
  console.log(chalk.gray('═'.repeat(50)));
  console.log(`  📦 运行时依赖：${depCount} 个`);
  console.log(`  🛠️  开发依赖：${devDepCount} 个`);
  console.log(`  📂 包管理器：${commands.install.split(' ')[0]}`);
  console.log(chalk.gray('═'.repeat(50)));
}

/**
 * 安装单个依赖
 * @param {string} projectDir - 项目目录
 * @param {string} packageName - 包名称
 * @param {boolean} isDev - 是否为开发依赖
 * @param {Object} config - 项目配置
 * @returns {Promise<void>}
 */
async function installPackage(projectDir, packageName, isDev, config) {
  const commands = getInstallCommand(config.packageManager || 'npm');
  const command = isDev ? commands.addDev : commands.add;
  
  return new Promise((resolve, reject) => {
    const spinner = ora(`正在安装 ${packageName}...`).start();
    
    const installProcess = exec(`${command} ${packageName}`, {
      cwd: projectDir,
      stdio: 'pipe',
      encoding: 'utf-8',
      maxBuffer: 10 * 1024 * 1024 // 10MB
    });

    installProcess.on('close', (code) => {
      if (code === 0) {
        spinner.succeed(`已安装 ${packageName}`);
        resolve();
      } else {
        spinner.fail(`安装 ${packageName} 失败`);
        reject(new Error(`安装 ${packageName} 失败，退出码：${code}`));
      }
    });

    installProcess.on('error', (error) => {
      spinner.fail(`安装 ${packageName} 失败`);
      reject(error);
    });
  });
}

/**
 * 卸载依赖
 * @param {string} projectDir - 项目目录
 * @param {string} packageName - 包名称
 * @param {Object} config - 项目配置
 * @returns {Promise<void>}
 */
async function uninstallPackage(projectDir, packageName, config) {
  const commands = getInstallCommand(config.packageManager || 'npm');
  const packageManager = config.packageManager || 'npm';
  
  return new Promise((resolve, reject) => {
    const spinner = ora(`正在卸载 ${packageName}...`).start();
    
    let command;
    if (packageManager === 'yarn') {
      command = `yarn remove ${packageName}`;
    } else if (packageManager === 'pnpm') {
      command = `pnpm remove ${packageName}`;
    } else {
      command = `npm uninstall ${packageName}`;
    }
    
    const uninstallProcess = exec(command, {
      cwd: projectDir,
      stdio: 'pipe',
      encoding: 'utf-8'
    });

    uninstallProcess.on('close', (code) => {
      if (code === 0) {
        spinner.succeed(`已卸载 ${packageName}`);
        resolve();
      } else {
        spinner.fail(`卸载 ${packageName} 失败`);
        reject(new Error(`卸载 ${packageName} 失败，退出码：${code}`));
      }
    });

    uninstallProcess.on('error', (error) => {
      spinner.fail(`卸载 ${packageName} 失败`);
      reject(error);
    });
  });
}

/**
 * 运行npm脚本
 * @param {string} projectDir - 项目目录
 * @param {string} scriptName - 脚本名称
 * @param {Object} config - 项目配置
 * @returns {Promise<void>}
 */
async function runScript(projectDir, scriptName, config) {
  const commands = getInstallCommand(config.packageManager || 'npm');
  const command = `${commands.run} ${scriptName}`;
  
  return new Promise((resolve, reject) => {
    console.log(chalk.cyan(`\n▶️  正在运行脚本：${scriptName}\n`));
    
    const scriptProcess = exec(command, {
      cwd: projectDir,
      stdio: 'inherit',
      encoding: 'utf-8',
      shell: process.platform === 'win32' ? 'cmd.exe' : '/bin/bash'
    });

    scriptProcess.on('close', (code) => {
      if (code === 0) {
        resolve();
      } else {
        reject(new Error(`脚本 "${scriptName}" 失败，退出码：${code}`));
      }
    });

    scriptProcess.on('error', (error) => {
      reject(error);
    });
  });
}

module.exports = {
  installDependencies,
  installPackage,
  uninstallPackage,
  runScript,
  getInstallCommand
};
