/**
 * package.json生成器
 * 
 * 根据配置生成package.json文件
 * 
 * @author DRAMVFIA UNION
 */

'use strict';

const fs = require('fs-extra');
const path = require('path');

/**
 * 生成package.json文件
 * @param {string} projectDir - 项目目录
 * @param {Object} config - 项目配置
 * @returns {Promise<void>}
 */
async function packageJson(projectDir, config) {
  const packageJsonPath = path.join(projectDir, 'package.json');

  // 获取依赖配置
  const dependencies = getDependencies(config);

  // 构建package.json内容
  const packageData = {
    name: config.projectName,
    version: config.projectVersion || '1.0.0',
    description: config.projectDescription || 'A Node.js project',
    main: config.typescript ? 'dist/index.js' : 'src/index.js',
    scripts: generateScripts(config),
    keywords: generateKeywords(config),
    author: config.author || '',
    license: config.license || 'MIT',
    repository: {
      type: 'git',
      url: 'git+https://github.com/user/repo.git'
    },
    bugs: {
      url: 'https://github.com/user/repo/issues'
    },
    homepage: 'https://github.com/user/repo#readme',
    engines: {
      node: config.nodeVersion || '>=18.0.0'
    },
   engines: {
  node: ">=18.0.0"
},
    dependencies: dependencies.dependencies,
    devDependencies: dependencies.devDependencies,
    jest: config.jest ? {
      testEnvironment: 'node',
      coverageDirectory: 'coverage',
      collectCoverageFrom: [
        'src/**/*.js',
        '!src/**/*.spec.js'
      ],
      testMatch: [
        '**/tests/**/*.spec.js'
      ],
      moduleFileExtensions: ['js', 'json'],
      verbose: true
    } : undefined,
    vitest: config.vitest ? {
      testEnvironment: 'node',
      coverage: {
        provider: 'v8',
        reporter: ['text', 'json', 'html']
      }
    } : undefined
  };

  // 如果是TypeScript项目，添加type字段
  if (config.typescript) {
    packageData.type = 'module';
  }

  // 移除undefined字段
  Object.keys(packageData).forEach(key => {
    if (packageData[key] === undefined) {
      delete packageData[key];
    }
  });

  await fs.writeJson(packageJsonPath, packageData, { spaces: 2 });
}

/**
 * 生成依赖配置
 * @param {Object} config - 项目配置
 * @returns {Object} 依赖对象
 */
function getDependencies(config) {
  const dependencies = {};
  const devDependencies = {
    'husky': '^8.0.3',
    'lint-staged': '^15.2.0'
  };

  // 基础运行时依赖
  if (config.framework === 'express') {
    dependencies['express'] = '^4.18.2';
    dependencies['cors'] = '^2.8.5';
    dependencies['dotenv'] = '^16.3.1';
    dependencies['morgan'] = '^1.10.0';
    dependencies['helmet'] = '^7.1.0';
    dependencies['compression'] = '^1.7.4';
  } else if (config.framework === 'koa') {
    dependencies['koa'] = '^2.14.2';
    dependencies['koa-router'] = '^12.0.1';
    dependencies['koa-bodyparser'] = '^4.4.1';
    dependencies['koa-cors'] = '^0.0.16';
    dependencies['koa-helmet'] = '^7.0.2';
    dependencies['koa-compress'] = '^5.1.1';
    dependencies['dotenv'] = '^16.3.1';
  } else if (config.framework === 'nestjs') {
    dependencies['@nestjs/core'] = '^10.3.0';
    dependencies['@nestjs/common'] = '^10.3.0';
    dependencies['@nestjs/platform-express'] = '^10.3.0';
    dependencies['reflect-metadata'] = '^0.2.1';
    dependencies['rxjs'] = '^7.8.1';
    dependencies['class-validator'] = '^0.14.0';
    dependencies['class-transformer'] = '^0.5.1';
  }

  // CLI工具不需要额外的Web依赖
  if (config.projectType === 'cli') {
    dependencies['commander'] = '^12.0.0';
    dependencies['chalk'] = '^5.3.0';
    dependencies['ora'] = '^8.0.1';
    dependencies['inquirer'] = '^9.2.12';
  }

  // TypeScript依赖
  if (config.typescript) {
    devDependencies['typescript'] = '^5.3.3';
    
    if (config.framework === 'express') {
      devDependencies['@types/express'] = '^4.17.21';
    } else if (config.framework === 'koa') {
      devDependencies['@types/koa'] = '^2.13.12';
      devDependencies['@types/koa__router'] = '^12.0.4';
      devDependencies['@types/koa-bodyparser'] = '^4.3.12';
    }
    
    devDependencies['@types/node'] = '^20.10.6';
    devDependencies['@types/compression'] = '^1.7.5';
    devDependencies['@types/cors'] = '^2.8.17';
    devDependencies['@types/morgan'] = '^1.9.9';
  }

  // ESLint依赖
  if (config.eslint) {
    devDependencies['eslint'] = '^8.56.0';
    devDependencies['eslint-config-prettier'] = '^9.1.0';
    devDependencies['eslint-plugin-prettier'] = '^5.1.2';
    
    if (config.typescript) {
      devDependencies['@typescript-eslint/parser'] = '^6.17.0';
      devDependencies['@typescript-eslint/eslint-plugin'] = '^6.17.0';
    }

    if (config.eslintConfig === 'airbnb') {
      devDependencies['eslint-config-airbnb'] = '^19.0.4';
      devDependencies['eslint-plugin-import'] = '^2.29.1';
      devDependencies['eslint-plugin-jsx-a11y'] = '^6.8.0';
      devDependencies['eslint-plugin-react'] = '^7.33.2';
      devDependencies['eslint-plugin-react-hooks'] = '^4.6.0';
    } else if (config.eslintConfig === 'standard') {
      devDependencies['eslint-config-standard'] = '^17.1.0';
      devDependencies['eslint-plugin-promise'] = '^6.1.1';
      devDependencies['eslint-plugin-import'] = '^2.29.1';
      devDependencies['eslint-plugin-n'] = '^16.4.0';
    }
  }

  // Prettier依赖
  if (config.prettier) {
    devDependencies['prettier'] = '^3.1.1';
  }

  // 测试框架依赖
  if (config.jest) {
    devDependencies['jest'] = '^29.7.0';
    if (config.typescript) {
      devDependencies['ts-jest'] = '^29.1.1';
      devDependencies['@types/jest'] = '^29.5.11';
    }
  } else if (config.vitest) {
    devDependencies['vitest'] = '^1.1.0';
    if (config.typescript) {
      devDependencies['@vitest/coverage-v8'] = '^1.1.0';
    }
  }

  // 其他开发依赖
  devDependencies['nodemon'] = '^3.0.2';
  
  if (config.projectType === 'api' || config.projectType === 'fullstack') {
    devDependencies['supertest'] = '^6.3.3';
  }

  return { dependencies, devDependencies };
}

/**
 * 生成npm脚本配置
 * @param {Object} config - 项目配置
 * @returns {Object} 脚本配置对象
 */
function generateScripts(config) {
  const scripts = {};

  // 基础脚本
  if (config.typescript) {
    scripts['build'] = 'tsc';
    scripts['start'] = 'node dist/index.js';
    scripts['dev'] = 'nodemon --exec ts-node src/index.ts';
  } else {
    scripts['start'] = 'node src/index.js';
    scripts['dev'] = 'nodemon src/index.js';
  }

  // 测试脚本
  if (config.jest) {
    scripts['test'] = 'jest';
    scripts['test:watch'] = 'jest --watch';
    scripts['test:coverage'] = 'jest --coverage';
  } else if (config.vitest) {
    scripts['test'] = 'vitest';
    scripts['test:watch'] = 'vitest watch';
    scripts['test:coverage'] = 'vitest run --coverage';
  } else {
    scripts['test'] = 'echo "Error: no test specified" && exit 1';
  }

  // 代码检查脚本
  if (config.eslint || config.prettier) {
    scripts['lint'] = 'eslint src/**/*.js';
    scripts['lint:fix'] = 'eslint src/**/*.js --fix';
    scripts['format'] = 'prettier --write src/**/*.js';
    scripts['format:check'] = 'prettier --check src/**/*.js';
  }

  // Git hooks
  if (config.husky) {
    scripts['prepare'] = 'husky install';
  }

  return scripts;
}

/**
 * 生成关键词
 * @param {Object} config - 项目配置
 * @returns {Array} 关键词数组
 */
function generateKeywords(config) {
  const keywords = ['nodejs', config.projectType];
  
  if (config.framework) {
    keywords.push(config.framework);
  }
  
  if (config.typescript) {
    keywords.push('typescript');
  }
  
  if (config.eslint) {
    keywords.push('eslint');
  }
  
  if (config.prettier) {
    keywords.push('prettier');
  }
  
  if (config.jest) {
    keywords.push('jest', 'testing');
  } else if (config.vitest) {
    keywords.push('vitest', 'testing');
  }

  return keywords;
}

module.exports = {
  packageJson
};
