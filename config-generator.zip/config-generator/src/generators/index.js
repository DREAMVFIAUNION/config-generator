/**
 * 生成器模块索引
 * 
 * 导出所有生成器模块
 * 
 * @author DRAMVFIA UNION
 */

'use strict';

const packageJson = require('./packageJson');
const projectStructure = require('./projectStructure');
const templates = require('./templates');
const dependencies = require('./dependencies');
const git = require('./git');

/**
 * 统一的生成器接口
 */
class Generator {
  constructor() {
    this.packageJson = packageJson;
    this.projectStructure = projectStructure;
    this.templates = templates;
    this.dependencies = dependencies;
    this.git = git;
  }

  /**
   * 生成完整的项目配置
   * @param {string} projectDir - 项目目录
   * @param {Object} config - 项目配置
   * @returns {Promise<Object>} 生成结果
   */
  async generateAll(projectDir, config) {
    const results = {
      success: true,
      files: [],
      errors: []
    };

    try {
      // 1. 生成package.json
      await this.packageJson.packageJson(projectDir, config);
      results.files.push('package.json');

      // 2. 生成项目结构
      await this.projectStructure.projectStructure(projectDir, config);
      results.files.push('项目目录结构');

      // 3. 生成配置文件模板
      await this.templates(projectDir, config);
      results.files.push('配置文件模板（ESLint、Prettier等）');

      // 4. 安装依赖
      if (config.installDependencies) {
        await this.dependencies.installDependencies(projectDir, config);
        results.files.push('依赖安装完成');
      }

      // 5. 初始化Git
      if (config.gitInit) {
        await this.git.initGit(projectDir);
        results.files.push('Git仓库初始化');
      }

      return results;
    } catch (error) {
      results.success = false;
      results.errors.push({
        message: error.message,
        stack: error.stack
      });
      return results;
    }
  }
}

module.exports = {
  Generator,
  packageJson,
  projectStructure,
  templates,
  dependencies,
  git,
  default: Generator
};
