/**
 * 基础配置问答模块
 * 
 * 收集项目基础信息（名称、描述、作者等）
 * 
 * @author DRAMVFIA UNION
 */

'use strict';

const inquirer = require('inquirer');
const chalk = require('chalk');

/**
 * 收集项目基础配置
 * @returns {Promise<Object>} 基础配置信息
 */
async function basic() {
  const questions = [
    {
      type: 'input',
      name: 'projectName',
      message: '请输入项目名称：',
      default: 'my-node-project',
      validate: (input) => {
        if (!input || input.trim().length === 0) {
          return '项目名称不能为空';
        }
        // 验证项目名称格式（允许字母、数字、中划线、下划线）
        const validName = /^[a-zA-Z0-9_-]+$/.test(input);
        if (!validName) {
          return '项目名称只能包含字母、数字、中划线(-)和下划线(_)';
        }
        return true;
      },
      filter: (input) => input.trim()
    },
    {
      type: 'input',
      name: 'projectDescription',
      message: '请输入项目描述：',
      default: 'A Node.js project',
      validate: (input) => {
        if (input && input.length > 200) {
          return '描述长度不能超过200个字符';
        }
        return true;
      },
      filter: (input) => input.trim()
    },
    {
      type: 'input',
      name: 'author',
      message: '请输入作者名称（可选）：',
      default: '',
      filter: (input) => input.trim()
    }
  ];

  console.log(chalk.cyan('\n📝 基础项目信息\n'));
  
  const answers = await inquirer.prompt(questions);
  return answers;
}

module.exports = {
  basic
};
