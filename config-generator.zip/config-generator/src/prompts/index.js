/**
 * 交互式问答模块索引
 * 
 * 导出所有问答模块
 * 
 * @author DRAMVFIA UNION
 */

'use strict';

module.exports = {
  basic: require('./basic'),
  projectType: require('./projectType'),
  typescript: require('./typescript'),
  linting: require('./linting'),
  testing: require('./testing'),
  other: require('./other')
};
