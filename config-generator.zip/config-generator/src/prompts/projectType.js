/**
 * 项目类型问答模块
 * 
 * 收集项目类型和框架选择
 * 
 * @author DRAMVFIA UNION
 */

'use strict';

const inquirer = require('inquirer');
const chalk = require('chalk');

/**
 * 收集项目类型配置
 * @returns {Promise<Object>} 项目类型配置
 */
async function projectType() {
  const questions = [
    {
      type: 'list',
      name: 'projectType',
      message: '请选择项目类型：',
      choices: [
        {
          name: '🔌 API服务 - 后端API接口服务',
          value: 'api'
        },
        {
          name: '🖥️ CLI工具 - 命令行应用程序',
          value: 'cli'
        },
        {
          name: '🌐 全栈应用 - 包含前端和后端',
          value: 'fullstack'
        }
      ],
      default: 'api'
    },
    {
      type: 'list',
      name: 'framework',
      message: '请选择框架类型：',
      choices: (answers) => {
        const frameworkOptions = [
          {
            name: '⚡ Express - 简洁灵活的Node.js Web框架',
            value: 'express'
          },
          {
            name: '🪷 Koa - 下一代Node.js Web框架',
            value: 'koa'
          },
          {
            name: '🛡️ NestJS - 构建高效、可扩展的企业级Node.js框架',
            value: 'nestjs'
          }
        ];

        if (answers.projectType === 'cli') {
          // CLI工具不需要Web框架，但保留选择以保持一致性
          return frameworkOptions.slice(0, 2);
        }
        return frameworkOptions;
      },
      default: (answers) => answers.projectType === 'cli' ? 'express' : 'express'
    }
  ];

  console.log(chalk.cyan('\n🏗️ 项目类型配置\n'));
  
  const answers = await inquirer.prompt(questions);
  return answers;
}

module.exports = {
  projectType
};
