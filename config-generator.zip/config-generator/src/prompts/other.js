/**
 * 其他配置问答模块
 * 
 * 收集其他杂项配置选项
 * 
 * @author DRAMVFIA UNION
 */

'use strict';

const inquirer = require('inquirer');
const chalk = require('chalk');

/**
 * 收集其他配置
 * @returns {Promise<Object>} 其他配置信息
 */
async function other() {
  const questions = [
    {
      type: 'list',
      name: 'packageManager',
      message: '请选择包管理器：',
      choices: [
        {
          name: 'npm - Node.js默认包管理器',
          value: 'npm'
        },
        {
          name: 'yarn - Facebook开发的快速包管理器',
          value: 'yarn'
        },
        {
          name: 'pnpm - 高效的节省磁盘空间的包管理器',
          value: 'pnpm'
        }
      ],
      default: 'npm'
    },
    {
      type: 'confirm',
      name: 'gitInit',
      message: '是否初始化Git仓库？',
      default: true
    },
    {
      type: 'confirm',
      name: 'installDependencies',
      message: '是否自动安装依赖包？',
      default: true
    },
    {
      type: 'list',
      name: 'license',
      message: '请选择开源许可证：',
      choices: [
        {
          name: 'MIT - 最宽松的开源许可证',
          value: 'MIT'
        },
        {
          name: 'Apache-2.0 - Apache许可证2.0',
          value: 'Apache-2.0'
        },
        {
          name: 'GPL-3.0 - GNU通用公共许可证3.0',
          value: 'GPL-3.0'
        },
        {
          name: 'UNLICENSED - 不开源',
          value: 'UNLICENSED'
        }
      ],
      default: 'MIT'
    },
    {
      type: 'input',
      name: 'nodeVersion',
      message: '请指定最低Node.js版本要求：',
      default: '>=18.0.0',
      validate: (input) => {
        // 验证版本号格式
        const validVersion = /^(>=|>|=)?\d+\.\d+\.\d+/.test(input);
        if (!validVersion) {
          return '请输入有效的版本号格式，如 >=18.0.0';
        }
        return true;
      },
      filter: (input) => input.trim()
    }
  ];

  console.log(chalk.cyan('\n⚙️ 其他配置\n'));
  
  const answers = await inquirer.prompt(questions);
  
  return {
    packageManager: answers.packageManager,
    gitInit: answers.gitInit,
    installDependencies: answers.installDependencies,
    license: answers.license,
    nodeVersion: answers.nodeVersion
  };
}

module.exports = {
  other
};
