/**
 * 代码规范配置问答模块
 * 
 * 收集ESLint和Prettier配置选项
 * 
 * @author DRAMVFIA UNION
 */

'use strict';

const inquirer = require('inquirer');
const chalk = require('chalk');

/**
 * 收集代码规范配置
 * @returns {Promise<Object>} 代码规范配置
 */
async function linting() {
  const questions = [
    {
      type: 'confirm',
      name: 'eslint',
      message: '是否启用ESLint代码规范检查？',
      default: true
    },
    {
      type: 'list',
      name: 'eslintConfig',
      message: '请选择ESLint配置风格：',
      choices: [
        {
          name: 'Standard - 标准JavaScript规范（无分号，无引号）',
          value: 'standard'
        },
        {
          name: 'Airbnb - Airbnb JavaScript规范（最严格）',
          value: 'airbnb'
        },
        {
          name: 'Prettier - 与Prettier配合使用的规范',
          value: 'prettier'
        },
        {
          name: 'Custom - 自定义ESLint配置',
          value: 'custom'
        }
      ],
      default: 'prettier',
      when: (answers) => answers.eslint
    },
    {
      type: 'confirm',
      name: 'prettier',
      message: '是否启用Prettier代码格式化？',
      default: true
    },
    {
      type: 'list',
      name: 'prettierConfig',
      message: '请选择Prettier配置方式：',
      choices: [
        {
          name: '.prettierrc.js - JavaScript配置文件',
          value: 'javascript'
        },
        {
          name: '.prettierrc.json - JSON配置文件',
          value: 'json'
        },
        {
          name: 'package.json - 在package.json中配置',
          value: 'package'
        }
      ],
      default: 'javascript',
      when: (answers) => answers.prettier
    },
    {
      type: 'confirm',
      name: 'husky',
      message: '是否启用Git Hooks（husky）进行提交前检查？',
      default: true,
      when: (answers) => answers.eslint || answers.prettier
    },
    {
      type: 'confirm',
      name: 'lintStaged',
      message: '是否启用lint-staged仅检查暂存区文件？',
      default: true,
      when: (answers) => (answers.eslint || answers.prettier) && answers.husky
    }
  ];

  console.log(chalk.cyan('\n🎨 代码规范配置\n'));
  
  const answers = await inquirer.prompt(questions);
  
  // 简化返回数据
  return {
    eslint: answers.eslint,
    eslintConfig: answers.eslintConfig,
    prettier: answers.prettier,
    prettierConfig: answers.prettierConfig,
    husky: answers.husky,
    lintStaged: answers.lintStaged
  };
}

module.exports = {
  linting
};
