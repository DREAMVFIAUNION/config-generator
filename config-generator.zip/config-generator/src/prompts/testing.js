/**
 * 测试框架配置问答模块
 * 
 * 收集测试框架选择和配置选项
 * 
 * @author DRAMVFIA UNION
 */

'use strict';

const inquirer = require('inquirer');
const chalk = require('chalk');

/**
 * 收集测试框架配置
 * @returns {Promise<Object>} 测试框架配置
 */
async function testing() {
  const questions = [
    {
      type: 'list',
      name: 'testFramework',
      message: '请选择测试框架：',
      choices: [
        {
          name: '🃏 Jest - Facebook开发的测试框架，功能全面',
          value: 'jest'
        },
        {
          name: '⚡ Vitest - 基于Vite的快速测试框架',
          value: 'vitest'
        },
        {
          name: '⏭️ 跳过 - 当前不配置测试框架',
          value: 'none'
        }
      ],
      default: 'jest'
    },
    {
      type: 'confirm',
      name: 'testCoverage',
      message: '是否启用测试覆盖率报告？',
      default: true,
      when: (answers) => answers.testFramework !== 'none'
    },
    {
      type: 'confirm',
      name: 'testWatch',
      message: '是否启用监听模式（watch mode）？',
      default: true,
      when: (answers) => answers.testFramework !== 'none'
    },
    {
      type: 'confirm',
      name: 'testCI',
      message: '是否为CI环境优化测试配置？',
      default: false,
      when: (answers) => answers.testFramework !== 'none'
    }
  ];

  console.log(chalk.cyan('\n🧪 测试框架配置\n'));
  
  const answers = await inquirer.prompt(questions);
  
  // 根据用户选择设置对应的测试框架标志
  return {
    jest: answers.testFramework === 'jest',
    vitest: answers.testFramework === 'vitest',
    testCoverage: answers.testCoverage,
    testWatch: answers.testWatch,
    testCI: answers.testCI
  };
}

module.exports = {
  testing
};
