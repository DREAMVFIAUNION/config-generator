/**
 * TypeScript配置问答模块
 * 
 * 收集TypeScript相关配置选项
 * 
 * @author DRAMVFIA UNION
 */

'use strict';

const inquirer = require('inquirer');
const chalk = require('chalk');

/**
 * 收集TypeScript配置
 * @returns {Promise<Object>} TypeScript配置
 */
async function typescript() {
  const questions = [
    {
      type: 'confirm',
      name: 'typescript',
      message: '是否启用TypeScript支持？',
      default: true,
      when: (answers) => {
        // CLI工具默认不启用TypeScript，但允许用户选择
        return true;
      }
    },
    {
      type: 'list',
      name: 'tsTarget',
      message: '请选择TypeScript编译目标版本：',
      choices: [
        {
          name: 'ES2020 - 支持现代浏览器和Node.js 14+',
          value: 'ES2020'
        },
        {
          name: 'ES2022 - 支持最新的语言特性',
          value: 'ES2022'
        },
        {
          name: 'ESNext - 支持最新的ECMAScript特性',
          value: 'ESNext'
        }
      ],
      default: 'ES2020',
      when: (answers) => answers.typescript
    },
    {
      type: 'list',
      name: 'tsModule',
      message: '请选择模块系统：',
      choices: [
        {
          name: 'commonjs - Node.js传统模块系统',
          value: 'commonjs'
        },
        {
          name: 'ESNext - ES模块系统',
          value: 'ESNext'
        }
      ],
      default: 'commonjs',
      when: (answers) => answers.typescript
    },
    {
      type: 'confirm',
      name: 'tsStrict',
      message: '是否启用严格类型检查模式？',
      default: true,
      when: (answers) => answers.typescript
    },
    {
      type: 'confirm',
      name: 'tsDeclarations',
      message: '是否生成类型声明文件（.d.ts）？',
      default: true,
      when: (answers) => answers.typescript
    }
  ];

  console.log(chalk.cyan('\n📘 TypeScript配置\n'));
  
  const answers = await inquirer.prompt(questions);
  
  // 简化返回数据，只保留必要的配置
  return {
    typescript: answers.typescript,
    tsTarget: answers.tsTarget,
    tsModule: answers.tsModule,
    tsStrict: answers.tsStrict,
    tsDeclarations: answers.tsDeclarations
  };
}

module.exports = {
  typescript
};
