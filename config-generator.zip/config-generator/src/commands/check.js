/**
 * check命令模块
 * 
 * 处理项目配置检查命令的执行逻辑
 * 
 * @author DRAMVFIA UNION
 */

'use strict';

const path = require('path');
const fs = require('fs-extra');
const chalk = require('chalk');
const ora = require('ora');

/**
 * 检查配置文件基础结构
 * @param {string} projectDir - 项目目录
 * @returns {Object} 检查结果
 */
async function checkConfig(projectDir) {
  const results = {
    exists: [],
    missing: [],
    warnings: [],
    errors: []
  };

  // 检查必须存在的文件
  const requiredFiles = [
    { name: 'package.json', required: true },
    { name: '.gitignore', required: true },
    { name: 'README.md', required: true }
  ];

  // 检查条件性文件
  const conditionalFiles = [
    { name: 'tsconfig.json', required: false, condition: (config) => config.typescript },
    { name: '.eslintrc.js', required: false, condition: (config) => config.eslint },
    { name: '.eslintrc.json', required: false, condition: (config) => config.eslint },
    { name: '.prettierrc.js', required: false, condition: (config) => config.prettier },
    { name: 'jest.config.js', required: false, condition: (config) => config.jest },
    { name: 'vitest.config.js', required: false, condition: (config) => config.vitest }
  ];

  // 检查文件是否存在
  for (const file of requiredFiles) {
    const filePath = path.join(projectDir, file.name);
    if (await fs.pathExists(filePath)) {
      results.exists.push(file.name);
    } else {
      results.missing.push({ name: file.name, reason: '缺少必需文件' });
    }
  }

  // 读取package.json获取配置信息
  let packageConfig = null;
  const packagePath = path.join(projectDir, 'package.json');
  if (await fs.pathExists(packagePath)) {
    try {
      packageConfig = await fs.readJson(packagePath);
    } catch (error) {
      results.errors.push({ name: 'package.json', reason: '无法解析JSON文件' });
    }
  }

  // 检查条件性文件
  if (packageConfig) {
    const hasTypescript = packageConfig.devDependencies && packageConfig.devDependencies.typescript;
    const hasEslint = packageConfig.devDependencies && packageConfig.devDependencies.eslint;
    const hasPrettier = packageConfig.devDependencies && packageConfig.devDependencies.prettier;
    const hasJest = packageConfig.devDependencies && packageConfig.devDependencies.jest;
    const hasVitest = packageConfig.devDependencies && packageConfig.devDependencies.vitest;

    for (const file of conditionalFiles) {
      const filePath = path.join(projectDir, file.name);
      const exists = await fs.pathExists(filePath);
      
      if (file.name === 'tsconfig.json' && hasTypescript && !exists) {
        results.missing.push({ name: file.name, reason: '检测到TypeScript依赖但缺少配置文件' });
      } else if (file.name.includes('eslintrc') && hasEslint && !exists) {
        results.missing.push({ name: file.name, reason: '检测到ESLint依赖但缺少配置文件' });
      } else if (file.name === '.prettierrc.js' && hasPrettier && !exists) {
        results.missing.push({ name: file.name, reason: '检测到Prettier依赖但缺少配置文件' });
      } else if (file.name === 'jest.config.js' && hasJest && !exists) {
        results.missing.push({ name: file.name, reason: '检测到Jest依赖但缺少配置文件' });
      } else if (file.name === 'vitest.config.js' && hasVitest && !exists) {
        results.missing.push({ name: file.name, reason: '检测到Vitest依赖但缺少配置文件' });
      } else if (exists) {
        results.exists.push(file.name);
      }
    }
  }

  // 检查src目录结构
  const srcDir = path.join(projectDir, 'src');
  if (await fs.pathExists(srcDir)) {
    const srcContents = await fs.readdir(srcDir);
    const requiredDirs = ['index.js'];
    const commonDirs = ['routes', 'controllers', 'models', 'services', 'utils'];
    
    // 检查必要文件
    for (const dir of requiredDirs) {
      if (srcContents.includes(dir)) {
        results.exists.push(`src/${dir}`);
      } else {
        results.warnings.push({ name: `src/${dir}`, reason: '建议创建入口文件' });
      }
    }
  } else {
    results.missing.push({ name: 'src/', reason: '缺少src源代码目录' });
  }

  // 检查tests目录
  const testsDir = path.join(projectDir, 'tests');
  if (await fs.pathExists(testsDir)) {
    results.exists.push('tests/');
  } else {
    results.warnings.push({ name: 'tests/', reason: '建议创建测试目录' });
  }

  // 检查package.json配置
  if (packageConfig) {
    // 检查scripts
    if (!packageConfig.scripts) {
      results.warnings.push({ name: 'scripts', reason: 'package.json中缺少scripts字段' });
    } else {
      const requiredScripts = ['start', 'dev', 'test'];
      for (const script of requiredScripts) {
        if (!packageConfig.scripts[script]) {
          results.warnings.push({ name: `scripts.${script}`, reason: `建议添加${script}脚本命令` });
        }
      }
    }

    // 检查engines
    if (!packageConfig.engines || !packageConfig.engines.node) {
      results.warnings.push({ name: 'engines', reason: '建议指定Node.js版本要求' });
    }

    // 检查license
    if (!packageConfig.license) {
      results.warnings.push({ name: 'license', reason: '建议指定项目许可证' });
    }
  }

  return results;
}

/**
 * 生成修复建议
 * @param {Object} results - 检查结果
 * @returns {Array} 修复建议列表
 */
function generateFixSuggestions(results) {
  const suggestions = [];

  for (const item of results.missing) {
    if (item.name === 'package.json') {
      suggestions.push({
        issue: '缺少package.json文件',
        solution: '运行 npm init -y 初始化package.json'
      });
    } else if (item.name === '.gitignore') {
      suggestions.push({
        issue: '缺少.gitignore文件',
        solution: '创建一个包含 node_modules、.env、dist 等的.gitignore文件'
      });
    } else if (item.name === 'README.md') {
      suggestions.push({
        issue: '缺少README.md文件',
        solution: '创建README.md文件，包含项目说明、安装步骤、使用方法等'
});
    } else if (item.name === 'tsconfig.json') {
      suggestions.push({
        issue: '缺少TypeScript配置文件',
        solution: '运行 npx tsc --init 生成tsconfig.json'
      });
    } else if (item.name.includes('eslintrc')) {
      suggestions.push({
        issue: '缺少ESLint配置文件',
        solution: '运行 npx eslint --init 生成ESLint配置'
      });
    } else if (item.name === '.prettierrc.js') {
      suggestions.push({
        issue: '缺少Prettier配置文件',
        solution: '创建.prettierrc.js文件，配置Prettier选项'
      });
    } else if (item.name === 'jest.config.js') {
      suggestions.push({
        issue: '缺少Jest配置文件',
        solution: '运行 npx jest --init 生成jest.config.js'
      });
    } else if (item.name === 'vitest.config.js') {
      suggestions.push({
        issue: '缺少Vitest配置文件',
        solution: '创建vitest.config.js文件，配置Vitest选项'
      });
    }
  }

  for (const item of results.warnings) {
    if (item.name === 'scripts.start') {
      suggestions.push({
        issue: '缺少start脚本',
        solution: '在package.json中添加 "start": "node src/index.js"'
      });
    } else if (item.name === 'scripts.dev') {
      suggestions.push({
        issue: '缺少dev脚本',
        solution: '在package.json中添加 "dev": "nodemon src/index.js"'
      });
    } else if (item.name === 'scripts.test') {
      suggestions.push({
        issue: '缺少test脚本',
        solution: '在package.json中添加 "test": "jest"'
      });
    }
  }

  return suggestions;
}

/**
 * 执行check命令
 * @param {string} directory - 要检查的目录
 * @param {Object} options - 命令行选项
 * @param {Object} globalOptions - 全局选项
 */
async function execute(directory, options, globalOptions) {
  const targetDir = path.resolve(process.cwd(), directory);

  console.log(chalk.cyan('\n🔍 正在检查项目配置...\n'));

  // 验证目录是否存在
  if (!await fs.pathExists(targetDir)) {
    console.error(chalk.red(`❌ 错误：目录 '${targetDir}' 不存在`));
    process.exit(1);
  }

  // 检查目录是否是有效的Node.js项目
  const packagePath = path.join(targetDir, 'package.json');
  const isNodeProject = await fs.pathExists(packagePath);

  if (!isNodeProject) {
    console.log(chalk.yellow(`⚠️  警告：目录 '${targetDir}' 中未找到package.json`));
    console.log(chalk.gray('这可能不是一个Node.js项目，或者package.json文件缺失。\n'));
  }

  // 执行检查
  const spinner = ora('正在分析项目配置...').start();
  let results;
  
  try {
    results = await checkConfig(targetDir);
    spinner.stop();
  } catch (error) {
    spinner.fail('配置检查失败！');
    console.error(chalk.red(`\n❌ 检查过程中发生错误：${error.message}`));
    process.exit(1);
  }

  // 显示检查结果
  console.log(chalk.cyan('📊 检查结果：\n'));

  // 显示已存在的配置
  if (results.exists.length > 0) {
    console.log(chalk.green('✅ 已存在的配置：'));
    for (const item of results.exists) {
      console.log(`   • ${item}`);
    }
    console.log();
  }

  // 显示缺失的配置
  if (results.missing.length > 0) {
    console.log(chalk.red('❌ 缺失的配置：'));
    for (const item of results.missing) {
      console.log(`   • ${item.name} - ${item.reason}`);
    }
    console.log();
  }

  // 显示警告
  if (results.warnings.length > 0) {
    console.log(chalk.yellow('⚠️  建议改进：'));
    for (const item of results.warnings) {
      console.log(`   • ${item.name} - ${item.reason}`);
    }
    console.log();
  }

  // 生成修复建议
  const suggestions = generateFixSuggestions(results);
  
  if (suggestions.length > 0) {
    console.log(chalk.cyan('💡 修复建议：'));
    console.log(chalk.gray('═'.repeat(50)));
    
    for (let i = 0; i < suggestions.length; i++) {
      const suggestion = suggestions[i];
      console.log(`\n${i + 1}. ${chalk.white(suggestion.issue)}`);
      console.log(`   ${chalk.cyan('解决方案：')}${suggestion.solution}`);
    }
    console.log(chalk.gray('═'.repeat(50)) + '\n');
  }

  // 计算配置完成度
  const totalRequired = 3 + results.missing.length + results.warnings.length;
  const score = Math.round((results.exists.length / totalRequired) * 100);

  console.log(chalk.cyan('📈 配置评分：'));
  let scoreColor = chalk.green;
  if (score < 60) scoreColor = chalk.red;
  else if (score < 80) scoreColor = chalk.yellow;
  
  console.log(`   ${scoreColor(`配置完成度：${score}%`)}\n`);

  // 自动修复
  if (options.fix) {
    console.log(chalk.cyan('🔧 自动修复功能开发中...\n'));
  }

  // 退出码
  if (results.missing.length > 0 || results.errors.length > 0) {
    process.exit(1);
  }
}

module.exports = {
  execute,
  checkConfig
};
