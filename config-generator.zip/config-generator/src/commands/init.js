/**
 * init命令模块
 * 
 * 处理项目初始化命令的执行逻辑
 * 
 * @author DRAMVFIA UNION
 */

'use strict';

const path = require('path');
const chalk = require('chalk');
const inquirer = require('inquirer');
const { ConfigGenerator } = require('../index');

/**
 * 执行init命令
 * @param {string} projectName - 项目名称
 * @param {Object} options - 命令行选项
 * @param {Object} globalOptions - 全局选项
 */
async function execute(projectName, options, globalOptions) {
  const generator = new ConfigGenerator();

  try {
    // 判断是否使用交互式模式
    if (Object.keys(options).length === 0 || 
        (Object.keys(options).length === 1 && projectName)) {
      // 交互式模式
      const hasQuickOptions = projectName || 
                            options.type || 
                            options.framework || 
                            options.typescript || 
                            options.eslint ||
                            options.prettier ||
                            options.jest ||
                            options.vitest;

      if (!hasQuickOptions) {
        // 完全交互式模式
        await generator.collectConfig();
      } else {
        // 部分交互式模式
        await generator.quickConfig(options, projectName);
      }
    } else {
      // 快速配置模式（所有选项都通过命令行指定）
      await generator.quickConfig(options, projectName);
    }

    // 设置目标目录
    const config = generator.projectConfig.getAll();
    let targetDir = config.projectName;
    
    // 如果指定了绝对路径或当前目录
    if (path.isAbsolute(targetDir)) {
      targetDir = targetName;
    } else if (projectName && !path.isAbsolute(projectName)) {
      // 检查是否是相对路径
      if (projectName.startsWith('.') || projectName.startsWith('/')) {
        targetDir = projectName;
      }
    } else {
      targetDir = path.resolve(process.cwd(), targetDir);
    }

    generator.projectConfig.setTargetDirectory(targetDir);

    // 生成项目文件
    const success = await generator.generate();

    if (success) {
      // 显示摘要
      generator.showSummary();
      
      console.log(chalk.green('\n✅ 项目初始化完成！'));
      console.log(chalk.gray('感谢使用 Node.js 配置生成器！'));
    }
  } catch (error) {
    if (error.isTtyError) {
      console.log(chalk.yellow('\n⚠️  无法在当前终端环境显示交互式提示。'));
      console.log(chalk.gray('请使用命令行参数来指定配置选项。'));
      console.log(chalk.cyan('\n使用示例：'));
      console.log('  $ config-gen init my-project --typescript --eslint --prettier'));
    } else {
      console.error(chalk.red('\n❌ 初始化过程中发生错误：'), error.message);
      if (globalOptions.verbose) {
        console.error(error.stack);
      }
    }
    process.exit(1);
  }
}

module.exports = {
  execute
};
