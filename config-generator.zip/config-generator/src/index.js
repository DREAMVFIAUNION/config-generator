/**
 * Node.js配置生成器核心模块
 * 
 * 智能化的项目配置生成器，帮助开发者快速初始化符合最佳实践的项目结构
 * 
 * @author DRAMVFIA UNION
 * @version 1.0.0
 */

'use strict';

const path = require('path');
const fs = require('fs-extra');
const chalk = require('chalk');
const ora = require('ora');
const inquirer = require('inquirer');

// 导入子模块
const prompts = require('./prompts');
const generators = require('./generators');
const utils = require('./utils');

/**
 * 项目配置类
 * 管理项目的配置信息和生成状态
 */
class ProjectConfig {
  constructor() {
    this.config = {
      projectName: '',
      projectDescription: '',
      projectVersion: '1.0.0',
      author: '',
      license: 'MIT',
      projectType: 'api',
      framework: 'express',
      typescript: false,
      eslint: true,
      prettier: true,
      jest: false,
      vitest: false,
      packageManager: 'npm',
      gitInit: true,
      installDependencies: true
    };
    this.targetDirectory = '';
  }

  /**
   * 更新配置项
   * @param {string} key - 配置键名
   * @param {*} value - 配置值
   */
  set(key, value) {
    if (Object.prototype.hasOwnProperty.call(this.config, key)) {
      this.config[key] = value;
    }
  }

  /**
   * 获取配置项
   * @param {string} key - 配置键名
   * @returns {*} 配置值
   */
  get(key) {
    return this.config[key];
  }

  /**
   * 获取完整配置对象
   * @returns {Object} 完整配置对象
   */
  getAll() {
    return { ...this.config };
  }

  /**
   * 设置目标目录
   * @param {string} directory - 目标目录路径
   */
  setTargetDirectory(directory) {
    this.targetDirectory = directory;
  }

  /**
   * 获取目标目录
   * @returns {string} 目标目录路径
   */
  getTargetDirectory() {
    return this.targetDirectory;
  }

  /**
   * 获取需要安装的依赖列表
   * @returns {Object} 依赖对象
   */
  getDependencies() {
    const deps = {};
    const devDeps = {};

    // 基础依赖
    if (this.config.framework === 'express') {
      deps['express'] = '^4.18.2';
      deps['cors'] = '^2.8.5';
      deps['dotenv'] = '^16.3.1';
      deps['morgan'] = '^1.10.0';
    } else if (this.config.framework === 'koa') {
      deps['koa'] = '^2.14.2';
      deps['koa-router'] = '^12.0.1';
      deps['koa-cors'] = '^0.0.16';
      deps['koa-bodyparser'] = '^4.4.1';
      deps['dotenv'] = '^16.3.1';
    } else if (this.config.framework === 'nestjs') {
      deps['@nestjs/core'] = '^10.3.0';
      deps['@nestjs/common'] = '^10.3.0';
      deps['@nestjs/platform-express'] = '^10.3.0';
      deps['reflect-metadata'] = '^0.2.1';
      deps['rxjs'] = '^7.8.1';
    }

    // TypeScript依赖
    if (this.config.typescript) {
      devDeps['typescript'] = '^5.3.3';
      if (this.config.framework === 'express') {
        devDeps['@types/express'] = '^4.17.21';
        devDeps['@types/node'] = '^20.10.6';
      } else if (this.config.framework === 'koa') {
        devDeps['@types/koa'] = '^2.13.12';
        devDeps['@types/node'] = '^20.10.6';
      }
    }

    // ESLint依赖
    if (this.config.eslint) {
      devDeps['eslint'] = '^8.56.0';
      if (this.config.typescript) {
        devDeps['@typescript-eslint/parser'] = '^6.17.0';
        devDeps['@typescript-eslint/eslint-plugin'] = '^6.17.0';
      }
      devDeps['eslint-config-prettier'] = '^9.1.0';
      devDeps['eslint-plugin-prettier'] = '^5.1.2';
    }

    // Prettier依赖
    if (this.config.prettier) {
      devDeps['prettier'] = '^3.1.1';
    }

    // 测试框架依赖
    if (this.config.jest) {
      devDeps['jest'] = '^29.7.0';
      if (this.config.typescript) {
        devDeps['ts-jest'] = '^29.1.1';
        devDeps['@types/jest'] = '^29.5.11';
      }
    } else if (this.config.vitest) {
      devDeps['vitest'] = '^1.1.0';
      if (this.config.typescript) {
        devDeps['@vitest/coverage-v8'] = '^1.1.0';
      }
    }

    // 其他开发依赖
    devDeps['husky'] = '^8.0.3';
    devDeps['lint-staged'] = '^15.2.0';

    return { dependencies: deps, devDependencies: devDeps };
  }
}

/**
 * 主应用程序类
 */
class ConfigGenerator {
  constructor() {
    this.projectConfig = new ProjectConfig();
  }

  /**
   * 交互式收集项目配置
   * @returns {Promise<Object>} 收集的配置信息
   */
  async collectConfig() {
    console.log(chalk.cyan('\n🚀 欢迎使用 Node.js 项目配置生成器\n'));
    console.log(chalk.gray('本工具将帮助您快速创建一个规范的Node.js项目配置。'));
    console.log(chalk.gray('请根据提示选择您的项目配置选项。\n'));

    // 收集基础信息
    const basicAnswers = await prompts.basic();
    this.projectConfig.set('projectName', basicAnswers.projectName);
    this.projectConfig.set('projectDescription', basicAnswers.projectDescription);
    this.projectConfig.set('author', basicAnswers.author);

    // 收集项目类型
    const typeAnswers = await prompts.projectType();
    this.projectConfig.set('projectType', typeAnswers.projectType);
    this.projectConfig.set('framework', typeAnswers.framework);

    // 收集TypeScript配置
    if (typeAnswers.projectType !== 'cli') {
      const tsAnswers = await prompts.typescript();
      this.projectConfig.set('typescript', tsAnswers.typescript);
    }

    // 收集代码规范配置
    const lintAnswers = await prompts.linting();
    this.projectConfig.set('eslint', lintAnswers.eslint);
    this.projectConfig.set('prettier', lintAnswers.prettier);

    // 收集测试框架配置
    const testAnswers = await prompts.testing();
    this.projectConfig.set('jest', testAnswers.jest);
    this.projectConfig.set('vitest', testAnswers.vitest);

    // 收集其他配置
    const otherAnswers = await prompts.other();
    this.projectConfig.set('packageManager', otherAnswers.packageManager);
    this.projectConfig.set('gitInit', otherAnswers.gitInit);
    this.projectConfig.set('installDependencies', otherAnswers.installDependencies);

    return this.projectConfig.getAll();
  }

  /**
   * 使用命令行参数快速配置
   * @param {Object} options - 命令行选项
   * @param {string} projectName - 项目名称
   */
  async quickConfig(options, projectName) {
    // 设置默认值
    this.projectConfig.set('projectName', projectName || 'my-node-project');
    this.projectConfig.set('projectDescription', 'A Node.js project');
    this.projectConfig.set('author', '');
    this.projectConfig.set('projectType', options.type || 'api');
    this.projectConfig.set('framework', options.framework || 'express');
    this.projectConfig.set('typescript', options.typescript || false);
    this.projectConfig.set('eslint', options.eslint !== false);
    this.projectConfig.set('prettier', options.prettier !== false);
    this.projectConfig.set('jest', options.jest || false);
    this.projectConfig.set('vitest', options.vitest || false);
    this.projectConfig.set('packageManager', 'npm');
    this.projectConfig.set('gitInit', true);
    this.projectConfig.set('installDependencies', true);
  }

  /**
   * 生成项目文件
   * @returns {Promise<boolean>} 生成是否成功
   */
  async generate() {
    const targetDir = this.projectConfig.getTargetDirectory();
    const config = this.projectConfig.getAll();

    try {
      // 验证目标目录
      if (await fs.pathExists(targetDir)) {
        const files = await fs.readdir(targetDir);
        if (files.length > 0) {
          console.log(chalk.yellow(`⚠️  目录 '${targetDir}' 已存在且不为空。`));
          const { confirm } = await inquirer.prompt([
            {
              type: 'confirm',
              name: 'confirm',
              message: '是否继续在现有文件上生成？这可能会覆盖某些文件。',
              default: false
            }
          ]);
          if (!confirm) {
            console.log(chalk.gray('已取消操作。'));
            return false;
          }
        }
      } else {
        await fs.ensureDir(targetDir);
      }

      // 生成package.json
      const spinner = ora('正在生成配置文件...').start();
      try {
        await generators.packageJson(targetDir, config);
        spinner.text = '正在生成项目结构...';
        await generators.projectStructure(targetDir, config);
        spinner.text = '正在生成模板文件...';
        await generators.templates(targetDir, config);
        spinner.succeed('配置文件生成完成！');
      } catch (error) {
        spinner.fail('配置文件生成失败！');
        throw error;
      }

      // 安装依赖
      if (config.installDependencies) {
        const depSpinner = ora('正在安装依赖包...').start();
        try {
          await generators.installDependencies(targetDir, config);
          depSpinner.succeed('依赖安装完成！');
        } catch (error) {
          depSpinner.fail('依赖安装失败！');
          console.log(chalk.yellow('请手动运行 npm install 安装依赖。'));
        }
      }

      // 初始化Git
      if (config.gitInit && !await fs.pathExists(path.join(targetDir, '.git'))) {
        const gitSpinner = ora('正在初始化Git仓库...').start();
        try {
          await generators.initGit(targetDir);
          gitSpinner.succeed('Git仓库初始化完成！');
        } catch (error) {
          gitSpinner.warn('Git仓库初始化失败，请手动初始化。');
        }
      }

      return true;
    } catch (error) {
      console.error(chalk.red(`\n❌ 生成过程中发生错误：`), error.message);
      return false;
    }
  }

  /**
   * 显示生成结果摘要
   */
  showSummary() {
    const config = this.projectConfig.getAll();
    
    console.log(chalk.cyan('\n📋 项目配置摘要：'));
    console.log(chalk.gray('═'.repeat(50)));
    console.log(`  项目名称：${chalk.white(config.projectName)}`);
    console.log(`  项目类型：${chalk.white(config.projectType)}`);
    console.log(`  框架选择：${chalk.white(config.framework)}`);
    console.log(`  TypeScript：${chalk.white(config.typescript ? '是' : '否')}`);
    console.log(`  ESLint：${chalk.white(config.eslint ? '是' : '否')}`);
    console.log(`  Prettier：${chalk.white(config.prettier ? '是' : '否')}`);
    console.log(`  Jest：${chalk.white(config.jest ? '是' : '否')}`);
    console.log(`  Vitest：${chalk.white(config.vitest ? '是' : '否')}`);
    console.log(chalk.gray('═'.repeat(50)));

    console.log(chalk.cyan('\n📁 生成的文件结构：'));
    console.log(chalk.gray('  ├── package.json'));
    console.log(chalk.gray('  ├── .gitignore'));
    console.log(chalk.gray('  ├── .eslintrc.js'));
    if (config.prettier) {
      console.log(chalk.gray('  ├── .prettierrc.js'));
    }
    if (config.typescript) {
      console.log(chalk.gray('  ├── tsconfig.json'));
    }
    if (config.jest) {
      console.log(chalk.gray('  ├── jest.config.js'));
    } else if (config.vitest) {
      console.log(chalk.gray('  ├── vitest.config.js'));
    }
    console.log(chalk.gray('  ├── src/'));
    console.log(chalk.gray('  │   ├── index.js'));
    if (config.projectType !== 'cli') {
      console.log(chalk.gray('  │   ├── routes/'));
      console.log(chalk.gray('  │   ├── controllers/'));
      console.log(chalk.gray('  │   ├── models/'));
    }
    console.log(chalk.gray('  ├── tests/'));
    if (config.projectType !== 'cli') {
      console.log(chalk.gray('  ├── public/'));
    }
    console.log(chalk.gray('  └── README.md'));

    console.log(chalk.cyan('\n💡 下一步操作：'));
    console.log(chalk.gray('  1. 进入项目目录：'), chalk.white(`cd ${config.projectName}`));
    console.log(chalk.gray('  2. 启动开发服务器：'), chalk.white('npm run dev'));
    console.log(chalk.gray('  3. 运行测试：'), chalk.white('npm test'));
    if (config.gitInit) {
      console.log(chalk.gray('  4. 创建第一个提交：'), chalk.white('git add . && git commit -m "feat: initial commit"'));
    }
    console.log();
  }
}

// 导出类和函数
module.exports = {
  ProjectConfig,
  ConfigGenerator,
  default: ConfigGenerator
};
