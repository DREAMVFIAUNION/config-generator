# Node.js Config Generator

智能化的Node.js项目配置生成器CLI工具，帮助开发者快速初始化符合最佳实践的项目结构。

## 功能特性

- 🚀 **快速初始化** - 交互式问答快速生成项目配置
- 🎨 **多框架支持** - 支持Express、Koa、NestJS等主流框架
- 📘 **TypeScript支持** - 一键启用TypeScript并配置最佳实践
- 🔍 **代码规范** - 内置ESLint和Prettier配置
- 🧪 **测试框架** - 支持Jest和Vitest测试框架
- 📦 **智能依赖** - 根据选择自动安装所需依赖
- 🔧 **配置检查** - 支持检查现有项目的配置规范性

## 快速开始

### 安装

```bash
# 使用npm全局安装
npm install -g config-generator

# 使用yarn全局安装
yarn global add config-generator

# 使用pnpm全局安装
pnpm add -g config-generator
```

### 使用

#### 交互式初始化

```bash
config-gen init
```

#### 指定配置初始化

```bash
# 创建TypeScript + ESLint + Prettier项目
config-gen init my-project --typescript --eslint --prettier

# 创建NestJS项目
config-gen init my-nestjs-app --framework nestjs --typescript --jest
```

#### 检查现有项目

```bash
# 检查当前目录
config-gen check

# 检查指定目录
config-gen check /path/to/project

# 检查并自动修复问题
config-gen check --fix
```

## 项目类型

| 项目类型 | 描述 |
|---------|------|
| `api` | 后端API服务 |
| `cli` | 命令行工具 |
| `fullstack` | 全栈应用 |

## 支持的框架

- **Express** - 简洁灵活的Node.js Web框架
- **Koa** - 下一代Node.js Web框架
- **NestJS** - 构建高效、可扩展的企业级Node.js框架

## 配置选项

### 命令行参数

| 参数 | 描述 |
|-----|------|
| `-t, --type <type>` | 项目类型（api、cli、fullstack） |
| `-f, --framework <framework>` | 框架类型（express、koa、nestjs） |
| `-ts, --typescript` | 启用TypeScript |
| `-e, --eslint` | 启用ESLint |
| `-p, --prettier` | 启用Prettier |
| `-j, --jest` | 启用Jest测试 |
| `-v, --vitest` | 启用Vitest测试 |

### 交互式选项

- 项目名称和描述
- 作者信息
- 包管理器选择（npm/yarn/pnpm）
- Node.js版本要求
- Git仓库初始化
- 自动依赖安装

## 生成的项目结构

```
my-project/
├── src/
│   ├── controllers/    # 控制器层
│   ├── routes/        # 路由定义
│   ├── models/         # 数据模型
│   ├── services/      # 业务逻辑
│   ├── middlewares/   # 中间件
│   ├── utils/         # 工具函数
│   ├── config/        # 配置文件
│   └── index.js       # 入口文件
├── tests/             # 测试文件
├── public/            # 静态资源
├── .env.example       # 环境变量示例
├── .gitignore
├── .eslintrc.js
├── .prettierrc.js
├── package.json
└── README.md
```

## 开发

### 环境要求

- Node.js >= 18.0.0
- npm >= 8.0.0

### 本地开发

```bash
# 克隆项目
git clone https://github.com/dramvfia/config-generator.git
cd config-generator

# 安装依赖
npm install

# 链接本地包
npm link

# 运行测试
npm test

# 开发模式运行
npm run dev
```

### 项目结构

```
config-generator/
├── bin/
│   └── config-gen.js       # CLI入口文件
├── src/
│   ├── index.js            # 主入口
│   ├── commands/           # 命令模块
│   │   ├── init.js         # init命令
│   │   └── check.js        # check命令
│   ├── prompts/            # 交互式问答
│   │   ├── basic.js        # 基础配置
│   │   ├── projectType.js  # 项目类型
│   │   ├── typescript.js   # TypeScript配置
│   │   ├── linting.js      # 代码规范
│   │   ├── testing.js      # 测试框架
│   │   └── other.js        # 其他配置
│   ├── generators/         # 生成器模块
│   │   ├── packageJson.js  # package.json生成
│   │   ├── projectStructure.js # 项目结构生成
│   │   ├── templates.js     # 配置文件模板
│   │   ├── dependencies.js  # 依赖安装
│   │   └── git.js          # Git初始化
│   └── utils/              # 工具函数
│       ├── fileSystem.js   # 文件操作
│       └── logger.js       # 日志输出
├── test/                   # 测试文件
├── templates/              # 模板文件
├── package.json
└── README.md
```

## 贡献

欢迎贡献代码！请阅读 [CONTRIBUTING.md](CONTRIBUTING.md) 了解贡献指南。

## License

MIT License

## 作者

**DRAMVFIA UNION**

## 致谢

感谢所有为这个项目做出贡献的人！
