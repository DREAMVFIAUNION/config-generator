# 贡献指南

感谢您对Node.js配置生成器项目的兴趣！我们欢迎各种形式的贡献，包括但不限于：

- 🐛 报告Bug
- 💡 提出新功能建议
- 📝 改进文档
- 🔧 提交代码修复
- ✨ 添加新功能

## 开发流程

### 1. Fork项目

点击GitHub页面右上角的Fork按钮，将项目fork到您的账户。

### 2. 克隆项目

```bash
git clone https://github.com/YOUR_USERNAME/config-generator.git
cd config-generator
```

### 3. 创建分支

```bash
git checkout -b feature/your-feature-name
```

### 4. 安装依赖

```bash
npm install
```

### 5. 开发

```bash
# 本地测试
npm run dev

# 运行测试
npm test

# 代码检查
npm run lint
```

### 6. 提交更改

```bash
git add .
git commit -m "feat: 添加新功能"
git push origin feature/your-feature-name
```

### 7. 创建Pull Request

在GitHub上创建Pull Request，描述您的更改。

## 代码规范

### JavaScript风格

- 使用ES6+语法
- 使用const和let，避免使用var
- 使用箭头函数
- 使用async/await处理异步操作

### 提交信息规范

```
feat: 新功能
fix: Bug修复
docs: 文档更新
style: 代码格式调整
refactor: 重构
test: 测试相关
chore: 构建或辅助工具
```

### 命名规范

- 文件：使用小写字母和连字符（kebab-case）
- 类：使用PascalCase
- 函数和变量：使用camelCase
- 常量：使用大写字母和下划线（UPPER_SNAKE_CASE）

## 测试

请确保您的更改通过所有测试：

```bash
npm test
```

如果添加了新功能，请添加相应的测试用例。

## 文档

如果您的更改影响用户使用，请更新相应的文档。

## 行为准则

请遵守 [Contributor Covenant](https://www.contributor-covenant.org/) 行为准则。
