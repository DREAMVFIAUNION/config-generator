/**
 * 基础测试文件
 * 
 * @author DRAMVFIA UNION
 */

'use strict';

describe('基础测试套件', () => {
  test('应该通过基本测试', () => {
    expect(1 + 1).toBe(2);
  });

  test('应该正确处理数组', () => {
    const arr = [1, 2, 3];
    expect(arr).toHaveLength(3);
    expect(arr).toContain(2);
  });

  test('应该正确处理对象', () => {
    const obj = { name: '测试', value: 42 };
    expect(obj).toHaveProperty('name');
    expect(obj.name).toBe('测试');
  });

  test('应该正确处理字符串', () => {
    const str = 'Hello World';
    expect(str).toContain('World');
    expect(str).toMatch(/Hello/);
  });
});

describe('异步测试', () => {
  test('应该正确处理Promise', async () => {
    const data = await Promise.resolve('异步数据');
    expect(data).toBe('异步数据');
  });

  test('应该正确处理async/await', async () => {
    const result = await new Promise(resolve => setTimeout(() => resolve('完成'), 10));
    expect(result).toBe('完成');
  });

  test('应该正确处理异步错误', async () => {
    await expect(
      new Promise((_, reject) => setTimeout(() => reject(new Error('错误')), 10))
    ).rejects.toThrow('错误');
  });
});

describe('测试工具函数', () => {
  test('should format file size correctly', () => {
    const { formatFileSize } = require('../src/utils/fileSystem');
    
    expect(formatFileSize(0)).toBe('0 Bytes');
    expect(formatFileSize(1024)).toBe('1 KB');
    expect(formatFileSize(1024 * 1024)).toBe('1 MB');
    expect(formatFileSize(1024 * 1024 * 1024)).toBe('1 GB');
  });

  test('should get file extension correctly', () => {
    const { getFileExtension } = require('../src/utils/fileSystem');
    
    expect(getFileExtension('test.js')).toBe('.js');
    expect(getFileExtension('test.ts')).toBe('.ts');
    expect(getFileExtension('test.config.js')).toBe('.js');
    expect(getFileExtension('README')).toBe('');
  });

  test('should get filename without extension correctly', () => {
    const { getFileNameWithoutExtension } = require('../src/utils/fileSystem');
    
    expect(getFileNameWithoutExtension('test.js')).toBe('test');
    expect(getFileNameWithoutExtension('test.ts')).toBe('test');
    expect(getFileNameWithoutExtension('test.config.js')).toBe('test.config');
  });
});

describe('配置生成器测试', () => {
  test('应该生成正确的scripts配置', () => {
    const { packageJson } = require('../src/generators/packageJson');
    
    const config = {
      projectName: 'test-project',
      projectDescription: '测试项目',
      projectVersion: '1.0.0',
      author: 'Test Author',
      license: 'MIT',
      projectType: 'api',
      framework: 'express',
      typescript: false,
      eslint: true,
      prettier: true,
      jest: true,
      vitest: false,
      nodeVersion: '>=18.0.0'
    };
    
    // 测试packageJson生成器存在
    expect(typeof packageJson).toBe('object');
  });

  test('应该支持TypeScript配置', () => {
    const generator = require('../src/index');
    
    const config = generator.ProjectConfig;
    expect(typeof config).toBe('function');
  });
});
