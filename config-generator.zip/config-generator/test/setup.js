/**
 * Jest测试设置文件
 * 
 * @author DRAMVFIA UNION
 */

// 测试超时设置
jest.setTimeout(10000);

// 全局Mock
jest.mock('chalk', () => ({
  cyan: jest.fn(text => text),
  gray: jest.fn(text => text),
  green: jest.fn(text => text),
  yellow: jest.fn(text => text),
  red: jest.fn(text => text),
  white: jest.fn(text => text),
  magenta: jest.fn(text => text)
}));

// 在测试结束后清理
afterAll(async () => {
  // 清理工作
});
